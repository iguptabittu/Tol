"""Create actual development Iceberg tables with deliberately small Parquet files."""
from pyspark.sql import SparkSession, functions as F

spark = SparkSession.builder.appName("IcebergOpsLocalSeed").getOrCreate()
spark.sql("CREATE NAMESPACE IF NOT EXISTS ops.analytics")
for name in ("events", "orders"):
    full = "ops.analytics." + name
    if spark.catalog.tableExists(full):
        print("Keeping existing table", full, flush=True)
        continue
    spark.sql(f"CREATE TABLE {full} (id BIGINT, event_type STRING, payload STRING) USING iceberg TBLPROPERTIES ('write.distribution-mode'='none')")
    for batch in range(3):
        frame = spark.range(batch * 4000, (batch + 1) * 4000).withColumn("event_type", F.lit(name)).withColumn("payload", F.sha2(F.col("id").cast("string"), 256))
        frame.repartition(8).writeTo(full).append()
    print("Created", full, "with", spark.table(full).count(), "rows", flush=True)
spark.stop()
