"""A local-only durable Spark job runner; no AWS API emulation or Docker socket."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, quote
from urllib.request import urlopen
from urllib.error import HTTPError
import hmac
import json
import os
import re
import signal
import subprocess
import threading
import time

import boto3

WORK = Path("/work")
TOKEN = os.environ.get("ICEBERG_OPS_LOCAL_TOKEN", "iceberg-local-development")
REST = os.environ.get("ICEBERG_REST_URI", "http://catalog:8181")
LOCK = threading.RLock()
ACTIVE_PROCESS = None
READY = False


def spark_command(script, *args):
    props = {
        "spark.sql.extensions": "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
        "spark.sql.catalog.ops": "org.apache.iceberg.spark.SparkCatalog",
        "spark.sql.catalog.ops.type": "rest", "spark.sql.catalog.ops.uri": REST,
        "spark.sql.catalog.ops.warehouse": "s3://warehouse/",
        "spark.sql.catalog.ops.io-impl": "org.apache.iceberg.aws.s3.S3FileIO",
        "spark.sql.catalog.ops.s3.endpoint": "http://minio:9000",
        "spark.sql.catalog.ops.s3.path-style-access": "true",
        "spark.sql.shuffle.partitions": "4", "spark.ui.showConsoleProgress": "false",
    }
    cmd = ["/opt/spark/bin/spark-submit", "--master", "local[2]", "--driver-memory", "1g"]
    for key, value in props.items():
        cmd.extend(["--conf", key + "=" + value])
    return [*cmd, str(script), *args]


def save(directory, data):
    temp = directory / "state.tmp"
    temp.write_text(json.dumps(data))
    temp.replace(directory / "state.json")


def job_directory(job_id):
    if not re.fullmatch(r"[a-f0-9-]{36}", job_id):
        raise ValueError("Invalid local job ID")
    return WORK / job_id


def load(directory):
    return json.loads((directory / "state.json").read_text())


def scheduler():
    global ACTIVE_PROCESS, READY
    s3 = boto3.client("s3")
    for _ in range(120):
        try:
            s3.list_buckets()
            with urlopen(REST + "/v1/config", timeout=3):
                pass
            break
        except Exception:
            time.sleep(1)
    for bucket in ("warehouse", "iceberg-ops-local"):
        try:
            s3.head_bucket(Bucket=bucket)
        except Exception:
            s3.create_bucket(Bucket=bucket)
    # A restart of this container stops its Spark processes; do not pretend they survived.
    for directory in WORK.iterdir():
        if (directory / "state.json").exists():
            state = load(directory)
            if state["state"] in {"RUNNING", "CANCELLING"}:
                state.update(state="FAILED", stateDetails="Local worker restarted during execution; rescan metadata")
                save(directory, state)
    with (WORK / "seed.log").open("ab") as log:
        seed = subprocess.run(spark_command("/app/local/seed.py"), stdout=log, stderr=subprocess.STDOUT)
        if seed.returncode:
            print("Seed failed. See /work/seed.log", flush=True)
            return
    READY = True
    print("Local Spark worker ready; real Iceberg tables are available", flush=True)
    while True:
        for directory in sorted(WORK.iterdir(), key=lambda p: p.name):
            if not (directory / "state.json").exists():
                continue
            with LOCK:
                state = load(directory)
                if state["state"] != "QUEUED":
                    continue
                state.update(state="RUNNING", startedAt=time.time())
                save(directory, state)
                manifest = json.loads((directory / "manifest.json").read_text())
                key = "iceberg-ops/manifests/" + state["id"] + ".json"
                try:
                    s3.put_object(Bucket="iceberg-ops-local", Key=key, Body=json.dumps(manifest).encode())
                    log = (directory / "driver.log").open("ab")
                    ACTIVE_PROCESS = subprocess.Popen(spark_command(directory / "job.py", "s3://iceberg-ops-local/" + key), stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                except Exception as error:
                    state.update(state="FAILED", stateDetails=str(error)[:2000], updatedAt=time.time())
                    save(directory, state)
                    if 'log' in locals() and not log.closed:
                        log.close()
                    continue
            timed_out = False
            try:
                returncode = ACTIVE_PROCESS.wait(timeout=60 * manifest.get("timeout_minutes", 60))
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(ACTIVE_PROCESS.pid, signal.SIGTERM)
                try:
                    returncode = ACTIVE_PROCESS.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(ACTIVE_PROCESS.pid, signal.SIGKILL)
                    returncode = ACTIVE_PROCESS.wait()
            log.close()
            with LOCK:
                state = load(directory)
                state["state"] = "CANCELLED" if state["state"] == "CANCELLING" else "SUCCESS" if returncode == 0 else "FAILED"
                state["updatedAt"] = time.time()
                state["totalExecutionDurationSeconds"] = round(time.time() - state["startedAt"])
                state["stateDetails"] = "Job exceeded its configured timeout" if timed_out else "Local Spark process exited with code " + str(returncode)
                save(directory, state)
                ACTIVE_PROCESS = None
        time.sleep(1)


class Handler(BaseHTTPRequestHandler):
    def respond(self, payload, status=200):
        raw = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        self.handle_request()

    def do_POST(self):
        self.handle_request()

    def handle_request(self):
        if not hmac.compare_digest(self.headers.get("X-Local-Token", ""), TOKEN):
            self.respond({"detail": "Local worker token required"}, 403)
            return
        try:
            url = urlparse(self.path)
            parts = url.path.strip("/").split("/")
            if url.path == "/health":
                self.respond({"ready": READY, "engine": "Spark 3.5.5 / Iceberg 1.9.0", "seed_log": (WORK/"seed.log").read_text(errors="replace")[-3000:] if not READY and (WORK/"seed.log").exists() else ""})
            elif url.path == "/tables":
                names = []
                for database in parse_qs(url.query).get("database", []):
                    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", database):
                        raise ValueError("Invalid namespace")
                    with urlopen(REST + "/v1/namespaces/" + quote(database) + "/tables", timeout=10) as response:
                        for table in json.load(response)["identifiers"]:
                            names.append(database + "." + table["name"])
                self.respond({"tables": sorted(names)})
            elif parts == ["jobs"] and self.command == "POST":
                if not READY:
                    self.respond({"detail": "Local tables are still being initialized"}, 503)
                    return
                length = int(self.headers.get("Content-Length", 0))
                if not 0 < length < 2 * 1024 * 1024:
                    raise ValueError("Invalid payload length")
                body = json.loads(self.rfile.read(length))
                directory = job_directory(body["id"])
                with LOCK:
                    if (directory / "state.json").exists():
                        self.respond(load(directory))
                        return
                    directory.mkdir(exist_ok=True)
                    (directory / "job.py").write_text(body["script"])
                    (directory / "manifest.json").write_text(json.dumps(body["manifest"]))
                    state = {"id": body["id"], "state": "QUEUED", "updatedAt": time.time(), "stateDetails": "Waiting for the local Spark executor"}
                    save(directory, state)
                self.respond(state, 202)
            elif len(parts) >= 2 and parts[0] == "jobs":
                directory = job_directory(parts[1])
                with LOCK:
                    state = load(directory)
                    if len(parts) == 3 and parts[2] == "cancel" and self.command == "POST":
                        if state["state"] == "QUEUED":
                            state["state"] = "CANCELLED"
                        elif state["state"] == "RUNNING":
                            state["state"] = "CANCELLING"
                            if ACTIVE_PROCESS:
                                os.killpg(ACTIVE_PROCESS.pid, signal.SIGTERM)
                        save(directory, state)
                    if len(parts) == 3 and parts[2] == "logs":
                        file = directory / "driver.log"
                        self.respond({"logs": file.read_text(errors="replace")[-40000:] if file.exists() else "Spark has not started yet."})
                    elif len(parts) == 3 and parts[2] == "result":
                        s3 = boto3.client("s3")
                        manifest = json.loads((directory / "manifest.json").read_text())
                        location = urlparse(manifest["result_uri"])
                        data = s3.get_object(Bucket=location.netloc, Key=location.path.lstrip("/"))["Body"].read()
                        self.respond(json.loads(data))
                    else:
                        self.respond(state)
            else:
                self.respond({"detail": "Not found"}, 404)
        except FileNotFoundError:
            self.respond({"detail": "Job not found"}, 404)
        except Exception as error:
            self.respond({"detail": str(error)[:2000]}, 400)


if __name__ == "__main__":
    WORK.mkdir(parents=True, exist_ok=True)
    threading.Thread(target=scheduler, daemon=True).start()
    ThreadingHTTPServer(("0.0.0.0", 8790), Handler).serve_forever()
