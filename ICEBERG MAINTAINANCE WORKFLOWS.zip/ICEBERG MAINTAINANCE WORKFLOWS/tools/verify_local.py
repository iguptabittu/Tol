"""Acceptance test against the real Docker lab. Compacts one local table only."""
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import json
import time

BASE = "http://127.0.0.1:8765"


def call(path, body=None):
    request = Request(BASE+path, data=json.dumps(body).encode() if body is not None else None,
        headers={"Content-Type": "application/json", "X-Ops-Request": "1"})
    try:
        with urlopen(request, timeout=40) as response:
            return json.load(response)
    except HTTPError as error:
        raise RuntimeError(json.load(error)) from None


def wait_run(workspace_id, run_id):
    prefix = "/api/workspaces/"+workspace_id
    for _ in range(120):
        run = next(r for r in call(prefix)["runs"] if r["id"] == run_id)
        if run["state"] in {"SUCCESS", "FAILED", "CANCELLED"} and not run["needs_result"]:
            if run["state"] != "SUCCESS":
                print(json.dumps(run, indent=2), flush=True)
                print(call(prefix+"/runs/"+run_id+"/logs")["logs"][-12000:], flush=True)
                raise RuntimeError("Local Spark job failed")
            return run
        time.sleep(2)
    raise TimeoutError("Local Spark job did not finish in four minutes")


def main():
    workspace = call("/api/local/workspace", {})
    assert workspace["backend"] == "local", "This acceptance test must never target AWS"
    prefix = "/api/workspaces/"+workspace["id"]
    scan = call(prefix+"/scan", {})
    print("Real local metadata scan:", scan["id"], flush=True)
    wait_run(workspace["id"], scan["id"])
    tables = call(prefix)["tables"]
    print("Measured tables:", [(t["name"], t["file_count"], t["small_files"]) for t in tables], flush=True)
    eligible = next((t for t in tables if t["eligible"]), None)
    if not eligible:
        print("No eligible backlog remains; metadata scan verified.", flush=True)
        return
    plan = call(prefix+"/plans", {"tables": [eligible["name"]]})
    maintenance = call(prefix+"/runs", {"plan_id": plan["id"], "approved": True})
    print("Real local compaction:", maintenance["id"], flush=True)
    run = wait_run(workspace["id"], maintenance["id"])
    measured = next(t for t in call(prefix)["tables"] if t["name"] == eligible["name"])
    assert measured["file_count"] < eligible["file_count"], "Expected real file reduction"
    print(json.dumps({"table": measured["name"], "files_before": eligible["file_count"], "files_after": measured["file_count"], "snapshot_before": eligible["snapshot_id"], "snapshot_after": measured["snapshot_id"], "spark_result": run["result"]["actions"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
