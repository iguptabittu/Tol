"""Generate the reviewable CloudFormation template. Makes no AWS calls."""
import json
from pathlib import Path

ref = lambda name: {"Ref": name}
sub = lambda text: {"Fn::Sub": text}
get = lambda name, attr: {"Fn::GetAtt": [name, attr]}
choose = lambda condition, yes, no: {"Fn::If": [condition, yes, no]}

bucket_properties = {
    "PublicAccessBlockConfiguration": {"BlockPublicAcls": True, "BlockPublicPolicy": True, "IgnorePublicAcls": True, "RestrictPublicBuckets": True},
    "BucketEncryption": {"ServerSideEncryptionConfiguration": [{"ServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]},
    "VersioningConfiguration": {"Status": "Enabled"},
}
data_bucket = choose("CreateDataBucket", ref("DataBucket"), ref("ExistingDataBucket"))
data_arn = choose("CreateDataBucket", get("DataBucket", "Arn"), sub("arn:${AWS::Partition}:s3:::${ExistingDataBucket}"))
data_objects = choose("CreateDataBucket", sub("${DataBucket.Arn}/${WarehousePrefix}*"), sub("arn:${AWS::Partition}:s3:::${ExistingDataBucket}/${WarehousePrefix}*"))
template = {
    "AWSTemplateFormatVersion": "2010-09-09",
    "Description": "Iceberg Ops: EMR Serverless, encrypted operations bucket, execution role, optional data bucket and Glue database.",
    "Parameters": {
        "ExistingDataBucket": {"Type": "String", "Default": "", "AllowedPattern": "^$|^[a-z0-9][a-z0-9.\\-]{1,61}[a-z0-9]$", "Description": "Existing data bucket; leave empty to create a dedicated one"},
        "WarehousePrefix": {"Type": "String", "Default": "warehouse/", "AllowedPattern": "^[A-Za-z0-9_/-]+/$", "Description": "Data prefix this role may read and write; must end in /"},
        "GlueDatabaseName": {"Type": "String", "Default": "iceberg_ops", "AllowedPattern": "^[a-z_][a-z0-9_]*$"},
        "CreateGlueDatabase": {"Type": "String", "Default": "true", "AllowedValues": ["true", "false"]},
        "ReleaseLabel": {"Type": "String", "Default": "emr-7.12.0", "AllowedPattern": "^emr-7\\.[0-9]+\\.[0-9]+$"},
        "DataKmsKeyArn": {"Type": "String", "Default": "", "Description": "Optional customer-managed KMS key used by existing data"},
    },
    "Conditions": {"CreateDataBucket": {"Fn::Equals": [ref("ExistingDataBucket"), ""]},
        "CreateDatabase": {"Fn::Equals": [ref("CreateGlueDatabase"), "true"]},
        "HasKmsKey": {"Fn::Not": [{"Fn::Equals": [ref("DataKmsKeyArn"), ""]}]}},
    "Resources": {
        "OperationsBucket": {"Type": "AWS::S3::Bucket", "DeletionPolicy": "Retain", "UpdateReplacePolicy": "Retain", "Properties": bucket_properties},
        "DataBucket": {"Type": "AWS::S3::Bucket", "Condition": "CreateDataBucket", "DeletionPolicy": "Retain", "UpdateReplacePolicy": "Retain", "Properties": bucket_properties},
        "GlueDatabase": {"Type": "AWS::Glue::Database", "Condition": "CreateDatabase", "DeletionPolicy": "Retain", "UpdateReplacePolicy": "Retain", "Properties": {"CatalogId": ref("AWS::AccountId"), "DatabaseInput": {"Name": ref("GlueDatabaseName")}}},
        "Application": {"Type": "AWS::EMRServerless::Application", "Properties": {
            "Name": sub("${AWS::StackName}-spark"), "Type": "SPARK", "ReleaseLabel": ref("ReleaseLabel"),
            "Architecture": "X86_64", "AutoStartConfiguration": {"Enabled": True},
            "AutoStopConfiguration": {"Enabled": True, "IdleTimeoutMinutes": 5},
            "MaximumCapacity": {"Cpu": "16 vCPU", "Memory": "64 GB", "Disk": "200 GB"}}},
        "ExecutionRole": {"Type": "AWS::IAM::Role", "Properties": {
            "AssumeRolePolicyDocument": {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Principal": {"Service": "emr-serverless.amazonaws.com"}, "Action": "sts:AssumeRole", "Condition": {"StringEquals": {"aws:SourceAccount": ref("AWS::AccountId")}, "ArnLike": {"aws:SourceArn": get("Application", "Arn")}}}]},
            "Policies": [{"PolicyName": "IcebergOpsDataAccess", "PolicyDocument": {"Version": "2012-10-17", "Statement": [
                {"Effect": "Allow", "Action": ["s3:ListBucket", "s3:GetBucketLocation"], "Resource": [get("OperationsBucket", "Arn"), data_arn]},
                {"Effect": "Allow", "Action": ["s3:GetObject", "s3:PutObject", "s3:AbortMultipartUpload", "s3:ListMultipartUploadParts"], "Resource": [sub("${OperationsBucket.Arn}/iceberg-ops/*")]},
                {"Effect": "Allow", "Action": ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:AbortMultipartUpload", "s3:ListMultipartUploadParts"], "Resource": [data_objects]},
                {"Effect": "Allow", "Action": ["glue:GetDatabase", "glue:GetDatabases", "glue:GetTable", "glue:GetTables", "glue:GetPartitions", "glue:UpdateTable"], "Resource": [sub("arn:${AWS::Partition}:glue:${AWS::Region}:${AWS::AccountId}:catalog"), sub("arn:${AWS::Partition}:glue:${AWS::Region}:${AWS::AccountId}:database/${GlueDatabaseName}"), sub("arn:${AWS::Partition}:glue:${AWS::Region}:${AWS::AccountId}:table/${GlueDatabaseName}/*")]},
                choose("HasKmsKey", {"Effect": "Allow", "Action": ["kms:Decrypt", "kms:Encrypt", "kms:GenerateDataKey", "kms:DescribeKey"], "Resource": ref("DataKmsKeyArn")}, ref("AWS::NoValue"))
            ]}}]}}
    },
    "Outputs": {"AccountId": {"Value": ref("AWS::AccountId")}, "Region": {"Value": ref("AWS::Region")},
        "ApplicationId": {"Value": ref("Application")}, "ExecutionRoleArn": {"Value": get("ExecutionRole", "Arn")},
        "OperationsBucket": {"Value": ref("OperationsBucket")}, "DataBucket": {"Value": data_bucket},
        "WarehouseUri": {"Value": choose("CreateDataBucket", sub("s3://${DataBucket}/${WarehousePrefix}"), sub("s3://${ExistingDataBucket}/${WarehousePrefix}"))},
        "GlueDatabase": {"Value": ref("GlueDatabaseName")}}
}

if __name__ == "__main__":
    path = Path(__file__).resolve().parents[1] / "infrastructure" / "cloudformation.json"
    path.write_text(json.dumps(template, indent=2) + "\n")
    print(path)
