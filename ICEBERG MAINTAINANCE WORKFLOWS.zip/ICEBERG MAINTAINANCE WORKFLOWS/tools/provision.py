"""Create a reviewable AWS change set; execution requires a separate explicit command."""
import argparse
import json
from pathlib import Path
import shlex
import sys
import time

import boto3


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", required=True)
    parser.add_argument("--account-id", required=True)
    parser.add_argument("--region", default="ap-south-1")
    parser.add_argument("--stack", default="iceberg-ops")
    parser.add_argument("--data-bucket", default="")
    parser.add_argument("--warehouse-prefix", default="warehouse/")
    parser.add_argument("--database", default="iceberg_ops")
    parser.add_argument("--existing-database", action="store_true")
    parser.add_argument("--kms-key", default="")
    args = parser.parse_args()
    session = boto3.Session(profile_name=args.profile, region_name=args.region)
    account = session.client("sts").get_caller_identity()["Account"]
    if account != args.account_id:
        parser.error("Signed-in account differs from --account-id")
    cloudformation = session.client("cloudformation")
    template = (Path(__file__).resolve().parents[1] / "infrastructure" / "cloudformation.json").read_text()
    cloudformation.validate_template(TemplateBody=template)
    from botocore.exceptions import ClientError
    try:
        cloudformation.describe_stacks(StackName=args.stack)
        mode = "UPDATE"
    except ClientError as error:
        if "does not exist" not in error.response["Error"]["Message"]:
            raise
        mode = "CREATE"
    response = cloudformation.create_change_set(StackName=args.stack,
        ChangeSetName="iceberg-ops-" + str(int(time.time())), ChangeSetType=mode,
        TemplateBody=template, Capabilities=["CAPABILITY_IAM"], Parameters=[
            {"ParameterKey": key, "ParameterValue": value} for key, value in {
                "ExistingDataBucket": args.data_bucket, "WarehousePrefix": args.warehouse_prefix,
                "GlueDatabaseName": args.database, "CreateGlueDatabase": "false" if args.existing_database else "true",
                "DataKmsKeyArn": args.kms_key}.items()])
    cloudformation.get_waiter("change_set_create_complete").wait(ChangeSetName=response["Id"], WaiterConfig={"Delay": 3, "MaxAttempts": 60})
    change_set = cloudformation.describe_change_set(ChangeSetName=response["Id"])
    for change in change_set.get("Changes", []):
        resource = change["ResourceChange"]
        print(resource["Action"], resource["LogicalResourceId"], resource["ResourceType"])
    print("\nNo resources have been deployed. Review the change set, then execute:")
    print(shlex.join(["aws", "cloudformation", "execute-change-set", "--change-set-name", response["Id"], "--profile", args.profile, "--region", args.region]))


if __name__ == "__main__":
    main()
