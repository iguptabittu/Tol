"""AWS calls live here; no access keys are accepted or persisted by the app."""
from pathlib import Path
import gzip
import hashlib
import json
import shlex

import boto3
from botocore.config import Config
from .models import IDENTIFIER

ROOT = Path(__file__).resolve().parents[1]


class AWSGateway:
    def session(self, workspace):
        session = boto3.Session(profile_name=workspace.get("aws_profile") or None,
                                region_name=workspace["region"])
        if workspace.get("assume_role_arn"):
            response = session.client("sts", config=self.config()).assume_role(
                RoleArn=workspace["assume_role_arn"], RoleSessionName="iceberg-ops")
            credentials = response["Credentials"]
            session = boto3.Session(region_name=workspace["region"],
                aws_access_key_id=credentials["AccessKeyId"],
                aws_secret_access_key=credentials["SecretAccessKey"],
                aws_session_token=credentials["SessionToken"])
        return session

    @staticmethod
    def config():
        return Config(connect_timeout=5, read_timeout=30, retries={"mode": "standard", "max_attempts": 2})

    def client(self, workspace, name):
        return self.session(workspace).client(name, config=self.config())

    @staticmethod
    def ready(workspace):
        required = ("account_id", "application_id", "execution_role_arn", "bucket", "warehouse", "databases")
        missing = [k for k in required if not workspace.get(k)]
        if missing:
            raise ValueError("Complete AWS setup: " + ", ".join(missing))
        if workspace["execution_role_arn"].split(":")[4] != workspace["account_id"]:
            raise ValueError("The execution role must belong to the selected AWS account")

    def check(self, workspace):
        self.ready(workspace)
        session = self.session(workspace)
        identity = session.client("sts", config=self.config()).get_caller_identity()
        if identity["Account"] != workspace["account_id"]:
            raise ValueError("Signed-in AWS account differs from the workspace account")
        app = session.client("emr-serverless", config=self.config()).get_application(
            applicationId=workspace["application_id"])["application"]
        if app.get("type") != "SPARK":
            raise ValueError("Select a Spark EMR Serverless application")
        session.client("s3", config=self.config()).head_bucket(Bucket=workspace["bucket"])
        glue = session.client("glue", config=self.config())
        for database in workspace["databases"]:
            glue.get_database(CatalogId=workspace["account_id"], Name=database)
        return {"account_id": identity["Account"], "principal": identity["Arn"],
                "application_state": app["state"], "release": app["releaseLabel"]}

    def discover(self, workspace):
        glue = self.client(workspace, "glue")
        tables = []
        for database in workspace["databases"]:
            for page in glue.get_paginator("get_tables").paginate(
                    CatalogId=workspace["account_id"], DatabaseName=database):
                for table in page["TableList"]:
                    parameters = {k.lower(): str(v) for k, v in table.get("Parameters", {}).items()}
                    if parameters.get("table_type", "").upper() == "ICEBERG" or parameters.get("metadata_location"):
                        if not IDENTIFIER.fullmatch(table["Name"]):
                            raise ValueError(f"Unsupported table identifier: {database}.{table['Name']}")
                        tables.append(f"{database}.{table['Name']}")
                        if len(tables) > 1000:
                            raise ValueError("Limit a workspace to at most 1,000 Iceberg tables")
        return sorted(set(tables))

    def submit(self, workspace, run):
        # Version-addressed scripts and a durable manifest keep token retries identical.
        self.ready(workspace)
        session = self.session(workspace)
        caller = session.client("sts", config=self.config()).get_caller_identity()
        if caller["Account"] != workspace["account_id"]:
            raise ValueError("AWS account changed; job submission blocked")
        s3 = session.client("s3", config=self.config())
        prefix = workspace["prefix"].strip("/")
        source = run["script"].encode()
        script_key = f"{prefix}/scripts/{hashlib.sha256(source).hexdigest()[:20]}.py"
        manifest_key = f"{prefix}/manifests/{run['id']}.json"
        for key, content in ((script_key, source), (manifest_key, json.dumps(run["manifest"], sort_keys=True).encode())):
            s3.put_object(Bucket=workspace["bucket"], Key=key, Body=content, ServerSideEncryption="AES256")
        props = {
            "spark.jars": "/usr/share/aws/iceberg/lib/iceberg-spark3-runtime.jar",
            "spark.sql.extensions": "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
            "spark.sql.catalog.ops": "org.apache.iceberg.spark.SparkCatalog",
            "spark.sql.catalog.ops.catalog-impl": "org.apache.iceberg.aws.glue.GlueCatalog",
            "spark.sql.catalog.ops.io-impl": "org.apache.iceberg.aws.s3.S3FileIO",
            "spark.sql.catalog.ops.warehouse": workspace["warehouse"],
            "spark.sql.catalog.ops.glue.id": workspace["account_id"],
            "spark.driver.cores": "2", "spark.driver.memory": "4g",
            "spark.executor.cores": "2", "spark.executor.memory": "4g",
            "spark.dynamicAllocation.enabled": "true",
            "spark.dynamicAllocation.initialExecutors": "1",
            "spark.dynamicAllocation.minExecutors": "1",
            "spark.dynamicAllocation.maxExecutors": "4",
        }
        parameters = " ".join("--conf " + shlex.quote(f"{key}={value}") for key, value in props.items())
        response = session.client("emr-serverless", config=self.config()).start_job_run(
            applicationId=workspace["application_id"], executionRoleArn=workspace["execution_role_arn"],
            clientToken=run["id"], name=f"iceberg-ops-{run['kind']}-{run['id'][:8]}",
            executionTimeoutMinutes=workspace["execution_timeout_minutes"],
            jobDriver={"sparkSubmit": {"entryPoint": f"s3://{workspace['bucket']}/{script_key}",
                "entryPointArguments": [f"s3://{workspace['bucket']}/{manifest_key}"],
                "sparkSubmitParameters": parameters}},
            configurationOverrides={"monitoringConfiguration": {"s3MonitoringConfiguration": {
                "logUri": f"s3://{workspace['bucket']}/{prefix}/logs/"}}},
            tags={"Application": "IcebergOps", "RunId": run["id"]})
        return response["jobRunId"]

    def poll(self, workspace, job_id):
        return self.client(workspace, "emr-serverless").get_job_run(
            applicationId=workspace["application_id"], jobRunId=job_id)["jobRun"]

    def cancel(self, workspace, job_id):
        self.client(workspace, "emr-serverless").cancel_job_run(
            applicationId=workspace["application_id"], jobRunId=job_id)

    def result(self, workspace, run):
        key = f"{workspace['prefix'].strip('/')}/results/{run['id']}.json"
        response = self.client(workspace, "s3").get_object(Bucket=workspace["bucket"], Key=key)
        if response["ContentLength"] > 20 * 1024 * 1024:
            raise ValueError("Job result exceeds 20 MB")
        return json.loads(response["Body"].read())

    def logs(self, workspace, job_id):
        prefix = f"{workspace['prefix'].strip('/')}/logs/applications/{workspace['application_id']}/jobs/{job_id}/SPARK_DRIVER/"
        s3 = self.client(workspace, "s3")
        entries = s3.list_objects_v2(Bucket=workspace["bucket"], Prefix=prefix, MaxKeys=50).get("Contents", [])
        parts = []
        for item in entries:
            if "stderr" not in item["Key"] and "stdout" not in item["Key"]:
                continue
            if item["Size"] > 10 * 1024 * 1024:
                parts.append("Log exceeds 10 MB; open the S3 log location.")
                continue
            raw = s3.get_object(Bucket=workspace["bucket"], Key=item["Key"])["Body"].read()
            if item["Key"].endswith(".gz"):
                raw = gzip.decompress(raw)
            parts.append(item["Key"].split("/")[-1] + "\n" + raw.decode("utf-8", "replace")[-20000:])
        return "\n\n".join(parts) or "Driver logs are not yet available in S3."
