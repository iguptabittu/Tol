from contextlib import contextmanager
from pathlib import Path
import json
import sqlite3
import threading

ACTIVE = ("SUBMITTING", "SUBMITTED", "PENDING", "SCHEDULED", "QUEUED", "RUNNING", "CANCELLING")


class Database:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        with self.transaction() as con:
            con.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS workspaces (id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS inventory (workspace_id TEXT NOT NULL, name TEXT NOT NULL,
                data TEXT NOT NULL, PRIMARY KEY(workspace_id,name));
            CREATE TABLE IF NOT EXISTS plans (id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL,
                data TEXT NOT NULL, consumed INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS runs (id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL,
                kind TEXT NOT NULL, state TEXT NOT NULL, job_id TEXT, schedule_id TEXT,
                occurrence TEXT, data TEXT NOT NULL, UNIQUE(schedule_id,occurrence,kind));
            CREATE UNIQUE INDEX IF NOT EXISTS one_active_run_per_workspace ON runs(workspace_id)
                WHERE state IN ('SUBMITTING','SUBMITTED','PENDING','SCHEDULED','QUEUED','RUNNING','CANCELLING');
            CREATE TABLE IF NOT EXISTS schedules (id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL,
                next_at TEXT NOT NULL, enabled INTEGER NOT NULL, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT,
                workspace_id TEXT, time TEXT NOT NULL, message TEXT NOT NULL);
            """)

    @contextmanager
    def transaction(self):
        with self.lock:
            con = sqlite3.connect(self.path, timeout=20)
            con.row_factory = sqlite3.Row
            try:
                con.execute("BEGIN IMMEDIATE")
                yield con
                con.commit()
            except BaseException:
                con.rollback()
                raise
            finally:
                con.close()

    def rows(self, query, args=()):
        with self.transaction() as con:
            return [dict(r) for r in con.execute(query, args).fetchall()]

    def execute(self, query, args=()):
        with self.transaction() as con:
            con.execute(query, args)


def pack(value):
    return json.dumps(value, separators=(",", ":"), default=str)


def unpack(row):
    return json.loads(row["data"])
