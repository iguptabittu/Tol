"""Iceberg Ops: a local control plane for real EMR Serverless jobs."""

__version__ = "1.0.0"
