from pydantic import BaseModel, Field, ConfigDict, field_validator, model_validator
import re

IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Policy(StrictModel):
    target_mb: int = Field(512, ge=64, le=2048)
    small_mb: int = Field(128, ge=1, le=1024)
    min_files: int = Field(5, ge=2, le=10000)
    max_group_gb: float = Field(8, ge=0.25, le=100)
    parallel_groups: int = Field(2, ge=1, le=8)
    cooldown_hours: int = Field(72, ge=0, le=8760)
    max_inventory_age_minutes: int = Field(60, ge=5, le=1440)

    @model_validator(mode="after")
    def consistent_sizes(self):
        if self.small_mb >= self.target_mb:
            raise ValueError("Small-file threshold must be smaller than the target size")
        if self.max_group_gb * 1024 < self.target_mb:
            raise ValueError("Group ceiling must be at least the target file size")
        return self


class Workspace(StrictModel):
    name: str = Field(min_length=1, max_length=100)
    backend: str = Field("aws", pattern=r"^(aws|local)$")
    account_id: str = Field("", pattern=r"^(?:\d{12})?$")
    region: str = Field("ap-south-1", pattern=r"^[a-z]{2}(?:-[a-z]+)+-\d+$")
    aws_profile: str = Field("", max_length=100, pattern=r"^[\w .@+\-]*$")
    assume_role_arn: str = Field("", max_length=2048, pattern=r"^(?:arn:aws:iam::\d{12}:role/[\w+=,.@/\-]+)?$")
    application_id: str = Field("", pattern=r"^[a-z0-9]{0,64}$")
    execution_role_arn: str = Field("", max_length=2048, pattern=r"^(?:arn:aws:iam::\d{12}:role/[\w+=,.@/\-]+)?$")
    bucket: str = Field("", max_length=63, pattern=r"^[a-z0-9][a-z0-9.\-]{1,61}[a-z0-9]$|^$")
    prefix: str = Field("iceberg-ops", max_length=120, pattern=r"^[A-Za-z0-9_\-/]+$")
    warehouse: str = Field("", max_length=1024, pattern=r"^s3://[a-z0-9][a-z0-9.\-]+/[^\s]*$|^$")
    databases: list[str] = Field(default_factory=list, max_length=100)
    policy: Policy = Field(default_factory=Policy)
    execution_timeout_minutes: int = Field(60, ge=5, le=720)

    @model_validator(mode="after")
    def local_defaults(self):
        if self.backend == "local":
            self.account_id = ""
            self.aws_profile = self.assume_role_arn = self.execution_role_arn = ""
            self.application_id = "local"
            self.region = "us-east-1"
            self.bucket = "iceberg-ops-local"
            self.prefix = "iceberg-ops"
            self.warehouse = "s3://warehouse/"
            self.databases = self.databases or ["analytics"]
        return self

    @field_validator("databases")
    @classmethod
    def valid_databases(cls, values):
        if any(not IDENTIFIER.fullmatch(v) for v in values):
            raise ValueError("Database names must use letters, numbers, and underscores")
        return sorted(set(values))

    @field_validator("name")
    @classmethod
    def trim_name(cls, value):
        if not value.strip():
            raise ValueError("A name is required")
        return value.strip()


class PlanRequest(StrictModel):
    tables: list[str] = Field(min_length=1, max_length=1000)
    policy: Policy | None = None


class StartRequest(StrictModel):
    plan_id: str
    approved: bool


class Schedule(StrictModel):
    name: str = Field(min_length=1, max_length=100)
    expression: str = Field(max_length=120)
    timezone: str = Field("Asia/Kolkata", max_length=100)
    scope: str = Field("auto", pattern=r"^(auto|selected)$")
    tables: list[str] = Field(default_factory=list, max_length=1000)
    policy: Policy = Field(default_factory=Policy)
    enabled: bool = False
    approved: bool = False

    @model_validator(mode="after")
    def validate_scope(self):
        if not self.name.strip():
            raise ValueError("A schedule name is required")
        if self.scope == "selected" and not self.tables:
            raise ValueError("Choose at least one table")
        if self.enabled and not self.approved:
            raise ValueError("Approve scheduled AWS jobs before enabling this schedule")
        for name in self.tables:
            bits = name.split(".")
            if len(bits) != 2 or not all(IDENTIFIER.fullmatch(b) for b in bits):
                raise ValueError("Invalid table name")
        return self
