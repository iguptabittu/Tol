from contextlib import asynccontextmanager
from pathlib import Path
import csv
import io
import os

import boto3
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from . import __version__
from .aws import ROOT
from .cron import next_occurrences
from .models import Workspace, Schedule, PlanRequest, StartRequest
from .service import Service, Engine, Conflict, error_message


def create_app(db_path=None, gateway=None, worker=True):
    db_path = db_path or os.environ.get("ICEBERG_OPS_DB", str(ROOT / "data" / "iceberg-ops.sqlite3"))
    service = Service(db_path, gateway)
    engine = Engine(service)

    @asynccontextmanager
    async def lifespan(app):
        if worker:
            engine.start()
        yield
        if worker:
            engine.stop()

    app = FastAPI(title="Iceberg Ops", version=__version__, lifespan=lifespan)
    app.state.service, app.state.engine = service, engine
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "[::1]", "testserver"])

    @app.middleware("http")
    async def local_boundary(request: Request, call_next):
        if request.method not in {"GET", "HEAD", "OPTIONS"}:
            origin = request.headers.get("origin")
            if request.headers.get("x-ops-request") != "1" or (origin and origin != str(request.base_url).rstrip("/")):
                return JSONResponse({"detail": "Cross-origin writes are not permitted"}, status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.exception_handler(KeyError)
    async def missing(request, error):
        return JSONResponse({"detail": str(error).strip("'")}, status_code=404)

    @app.exception_handler(Conflict)
    async def conflict(request, error):
        return JSONResponse({"detail": str(error)}, status_code=409)

    @app.exception_handler(ValueError)
    async def invalid(request, error):
        return JSONResponse({"detail": str(error)}, status_code=400)

    @app.get("/api/health")
    def health():
        return {"ok": True, "version": __version__, "worker": bool(engine.thread and engine.thread.is_alive())}

    @app.get("/api/system")
    def system():
        return {"version": __version__, "profiles": boto3.Session().available_profiles,
                "scheduler": "Local backend; this Mac must remain awake for scheduled submissions",
                "workspaces": service.workspaces()}

    @app.get("/api/cron")
    def cron(expression: str, timezone: str = "UTC"):
        return {"occurrences": next_occurrences(expression, timezone)}

    @app.post("/api/workspaces", status_code=201)
    def add_workspace(body: Workspace):
        return service.save_workspace(body)

    @app.post("/api/local/workspace")
    def local_workspace():
        model = Workspace(name="Local Docker · Iceberg", backend="local", databases=["analytics"])
        service.gateway.check(model.model_dump())
        existing = next((w for w in service.workspaces() if w.get("backend") == "local"), None)
        result = existing or service.save_workspace(model)
        service.check_connection(result["id"])
        return service.workspace(result["id"])

    @app.put("/api/workspaces/{workspace_id}")
    def update_workspace(workspace_id: str, body: Workspace):
        service.workspace(workspace_id)
        return service.save_workspace(body, workspace_id)

    @app.get("/api/workspaces/{workspace_id}")
    def overview(workspace_id: str):
        return service.overview(workspace_id)

    @app.post("/api/workspaces/{workspace_id}/check")
    def check(workspace_id: str):
        return service.check_connection(workspace_id)

    @app.post("/api/workspaces/{workspace_id}/scan", status_code=202)
    def scan(workspace_id: str):
        return service.scan(workspace_id)

    @app.post("/api/workspaces/{workspace_id}/plans", status_code=201)
    def plan(workspace_id: str, body: PlanRequest):
        return service.make_plan(workspace_id, body.tables, body.policy.model_dump() if body.policy else None)

    @app.post("/api/workspaces/{workspace_id}/runs", status_code=202)
    def run(workspace_id: str, body: StartRequest):
        return service.start_plan(workspace_id, body.plan_id, body.approved)

    @app.post("/api/workspaces/{workspace_id}/runs/{run_id}/cancel")
    def cancel(workspace_id: str, run_id: str):
        return service.cancel(workspace_id, run_id)

    @app.get("/api/workspaces/{workspace_id}/runs/{run_id}/logs")
    def logs(workspace_id: str, run_id: str):
        run = service.raw_run(run_id)
        if run["workspace_id"] != workspace_id:
            raise KeyError("Run not found")
        if not run["job_id"]:
            return {"logs": "Job has not been accepted by AWS yet."}
        try:
            return {"logs": service.gateway.logs(run["workspace"], run["job_id"])}
        except Exception as error:
            return JSONResponse({"detail": error_message(error)}, status_code=502)

    @app.post("/api/workspaces/{workspace_id}/schedules", status_code=201)
    def add_schedule(workspace_id: str, body: Schedule):
        return service.save_schedule(workspace_id, body)

    @app.put("/api/workspaces/{workspace_id}/schedules/{schedule_id}")
    def update_schedule(workspace_id: str, schedule_id: str, body: Schedule):
        return service.save_schedule(workspace_id, body, schedule_id)

    @app.delete("/api/workspaces/{workspace_id}/schedules/{schedule_id}", status_code=204)
    def delete_schedule(workspace_id: str, schedule_id: str):
        service.delete_schedule(workspace_id, schedule_id)
        return Response(status_code=204)

    @app.get("/api/workspaces/{workspace_id}/history.csv")
    def history(workspace_id: str):
        service.workspace(workspace_id)
        stream = io.StringIO()
        writer = csv.writer(stream)
        writer.writerow(["Run", "Kind", "State", "Created", "AWS job", "Duration seconds", "vCPU hours", "Memory GB hours"])
        for run in service.runs(workspace_id):
            usage = run.get("usage") or {}
            writer.writerow([run["id"], run["kind"], run["state"], run["created_at"], run["job_id"], run.get("duration_seconds"), usage.get("vCPUHour"), usage.get("memoryGBHour")])
        return Response(stream.getvalue(), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="iceberg-runs.csv"'})

    @app.get("/api/workspaces/{workspace_id}/schedules.json")
    def schedules_export(workspace_id: str):
        service.workspace(workspace_id)
        return JSONResponse(service.schedules(workspace_id), headers={"Content-Disposition": 'attachment; filename="iceberg-schedules.json"'})

    @app.get("/api/setup/template")
    def template():
        return FileResponse(ROOT / "infrastructure" / "cloudformation.json", filename="iceberg-ops-cloudformation.json")

    @app.get("/api/setup/guide")
    def guide():
        return FileResponse(ROOT / "docs" / "SETUP.md", media_type="text/plain")

    @app.get("/api/setup/local-guide")
    def local_guide():
        return FileResponse(ROOT / "docs" / "LOCAL_DOCKER.md", media_type="text/plain")

    app.mount("/assets", StaticFiles(directory=ROOT / "web"), name="assets")

    @app.get("/")
    def home():
        return FileResponse(ROOT / "web" / "index.html")

    return app
