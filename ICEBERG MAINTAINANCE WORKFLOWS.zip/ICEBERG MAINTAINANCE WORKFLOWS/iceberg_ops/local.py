"""Local Spark executor adapter. Endpoints come from trusted process configuration."""
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError
import json
import os
from datetime import datetime, timezone

from .aws import AWSGateway


class LocalGateway:
    @staticmethod
    def ready(workspace):
        if not workspace.get("databases"):
            raise ValueError("Choose at least one local Iceberg namespace")

    def request(self, path, body=None):
        endpoint = os.environ.get("ICEBERG_OPS_LOCAL_WORKER_URL", "http://127.0.0.1:8790").rstrip("/")
        request = Request(endpoint + path, data=json.dumps(body).encode() if body is not None else None,
            headers={"Content-Type": "application/json", "X-Local-Token": os.environ.get("ICEBERG_OPS_LOCAL_TOKEN", "iceberg-local-development")})
        try:
            with urlopen(request, timeout=30) as response:
                return json.load(response)
        except HTTPError as error:
            try:
                detail = json.load(error).get("detail", str(error))
            except Exception:
                detail = str(error)
            raise ValueError("Local Spark: " + detail) from None
        except URLError:
            raise ValueError("Local Docker services are unavailable. Start them with docker compose -f compose.local.yaml up -d --build") from None

    def check(self, workspace):
        self.ready(workspace)
        result = self.request("/health")
        if not result["ready"]:
            raise ValueError("Docker is preparing local Iceberg tables. Try again shortly. " + result.get("seed_log", "")[-700:])
        return {"account_id": "Local Docker", "principal": "Local Spark executor", "application_state": "READY", "release": result["engine"]}

    def discover(self, workspace):
        return self.request("/tables?" + urlencode({"database": workspace["databases"]}, doseq=True))["tables"]

    def submit(self, workspace, run):
        return self.request("/jobs", {"id": run["id"], "script": run["script"], "manifest": run["manifest"]})["id"]

    def poll(self, workspace, job_id):
        result = self.request("/jobs/" + job_id)
        if isinstance(result.get("updatedAt"), (int, float)):
            result["updatedAt"] = datetime.fromtimestamp(result["updatedAt"], timezone.utc).isoformat()
        return result

    def cancel(self, workspace, job_id):
        self.request("/jobs/" + job_id + "/cancel", {})

    def result(self, workspace, run):
        return self.request("/jobs/" + run["id"] + "/result")

    def logs(self, workspace, job_id):
        return self.request("/jobs/" + job_id + "/logs")["logs"]


class GatewayRouter:
    def __init__(self):
        self.aws, self.local = AWSGateway(), LocalGateway()

    def select(self, workspace):
        return self.local if workspace.get("backend") == "local" else self.aws

    def __getattr__(self, name):
        def dispatch(workspace, *args):
            return getattr(self.select(workspace), name)(workspace, *args)
        return dispatch
