from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
import math
import sqlite3
import threading
import time
import uuid

from botocore.exceptions import BotoCoreError, ClientError
from .aws import AWSGateway, ROOT
from .cron import next_occurrences
from .database import ACTIVE, Database, pack, unpack
from .models import Policy, Workspace, Schedule
from .local import GatewayRouter
from jobs.iceberg_job import sql_for


def now():
    return datetime.now(timezone.utc).isoformat()


def uid():
    return str(uuid.uuid4())


def error_message(error):
    if isinstance(error, ClientError):
        detail = error.response.get("Error", {})
        return f"{detail.get('Code', 'AWS error')}: {detail.get('Message', '')}"[:2000]
    if type(error).__name__ in {"NoCredentialsError", "ProfileNotFound", "SSOTokenLoadError", "UnauthorizedSSOTokenError", "TokenRetrievalError"}:
        return "AWS login is unavailable or expired. Configure an AWS profile, then run aws sso login --profile YOUR_PROFILE."
    return str(error)[:2000]


class Conflict(ValueError):
    pass


class Service:
    def __init__(self, path, gateway=None):
        self.db = Database(path)
        self.gateway = gateway or GatewayRouter()

    def event(self, workspace_id, message):
        self.db.execute("INSERT INTO events(workspace_id,time,message) VALUES(?,?,?)", (workspace_id, now(), message))

    def workspace(self, workspace_id):
        rows = self.db.rows("SELECT data FROM workspaces WHERE id=?", (workspace_id,))
        if not rows:
            raise KeyError("Workspace not found")
        return unpack(rows[0])

    def workspaces(self):
        return [unpack(row) for row in self.db.rows("SELECT data FROM workspaces ORDER BY rowid")]

    def save_workspace(self, model: Workspace, workspace_id=None):
        workspace_id = workspace_id or uid()
        old = self.workspace(workspace_id) if self.db.rows("SELECT id FROM workspaces WHERE id=?", (workspace_id,)) else None
        data = {**model.model_dump(), "id": workspace_id, "updated_at": now(), "connection": None}
        with self.db.transaction() as con:
            active = con.execute("SELECT id FROM runs WHERE workspace_id=? AND state IN (" + ",".join("?" * len(ACTIVE)) + ")", (workspace_id, *ACTIVE)).fetchone()
            if active:
                raise Conflict("Wait for or cancel the active job before changing workspace settings")
            # Existing schedule permissions refer to this exact AWS target.
            target = ("backend", "account_id", "region", "application_id", "execution_role_arn", "bucket", "prefix", "warehouse", "databases", "assume_role_arn", "aws_profile")
            target_changed = old and any(old.get(key) != data.get(key) for key in target)
            if target_changed:
                schedules = con.execute("SELECT * FROM schedules WHERE workspace_id=?", (workspace_id,)).fetchall()
                for row in schedules:
                    schedule = unpack(row)
                    schedule.update(enabled=False, approved=False, last_error="AWS target changed; review and enable again")
                    con.execute("UPDATE schedules SET enabled=0,data=? WHERE id=?", (pack(schedule), schedule["id"]))
                con.execute("DELETE FROM inventory WHERE workspace_id=?", (workspace_id,))
                con.execute("DELETE FROM plans WHERE workspace_id=?", (workspace_id,))
            con.execute("INSERT OR REPLACE INTO workspaces(id,data) VALUES(?,?)", (workspace_id, pack(data)))
        self.event(workspace_id, "Workspace configuration saved" + ("; schedules paused because AWS target changed" if target_changed else ""))
        return data

    def check_connection(self, workspace_id):
        workspace = self.workspace(workspace_id)
        try:
            connection = {"ok": True, "checked_at": now(), **self.gateway.check(workspace)}
        except Exception as error:
            connection = {"ok": False, "checked_at": now(), "error": error_message(error)}
        # Do not overwrite concurrent edits with the old configuration.
        with self.db.transaction() as con:
            row = con.execute("SELECT data FROM workspaces WHERE id=?", (workspace_id,)).fetchone()
            current = unpack(row)
            if current["updated_at"] == workspace["updated_at"]:
                current["connection"] = connection
                con.execute("UPDATE workspaces SET data=? WHERE id=?", (pack(current), workspace_id))
        label = "Local Docker" if workspace.get("backend") == "local" else "AWS"
        self.event(workspace_id, label + " connection verified" if connection["ok"] else connection["error"])
        return connection

    def inventory(self, workspace_id):
        return [unpack(row) for row in self.db.rows("SELECT data FROM inventory WHERE workspace_id=? ORDER BY name", (workspace_id,))]

    def assess(self, item, policy):
        item = {**item, "eligible": False, "reasons": [], "blocked": []}
        if item.get("error"):
            item["blocked"].append(item["error"])
        if not item.get("scanned_at") or datetime.fromisoformat(item["scanned_at"]) < datetime.now(timezone.utc) - timedelta(minutes=policy["max_inventory_age_minutes"]):
            item["blocked"].append("Inventory is stale; refresh metadata")
        if item.get("small_mb") != policy["small_mb"]:
            item["blocked"].append("Small-file threshold changed; refresh metadata")
        if item.get("small_files", 0) < policy["min_files"]:
            item["blocked"].append("Below the minimum small-file count")
        last = item.get("last_maintenance_at")
        if last and datetime.fromisoformat(last) + timedelta(hours=policy["cooldown_hours"]) > datetime.now(timezone.utc):
            item["blocked"].append("Within maintenance cooldown")
        if not item.get("snapshot_id"):
            item["blocked"].append("No current data snapshot")
        if item.get("small_files", 0):
            item["reasons"].append(f"{item['small_files']} files smaller than {policy['small_mb']} MB")
        item["eligible"] = not item["blocked"]
        return item

    def overview(self, workspace_id):
        workspace = self.workspace(workspace_id)
        tables = [self.assess(t, workspace["policy"]) for t in self.inventory(workspace_id)]
        tables.sort(key=lambda t: t.get("small_files", 0), reverse=True)
        return {"workspace": workspace, "tables": tables, "runs": self.runs(workspace_id),
            "schedules": self.schedules(workspace_id), "events": self.db.rows(
                "SELECT time,message FROM events WHERE workspace_id=? ORDER BY id DESC LIMIT 100", (workspace_id,))}

    def make_plan(self, workspace_id, names, policy=None):
        workspace = self.workspace(workspace_id)
        self.gateway.ready(workspace)
        policy = Policy.model_validate(policy or workspace["policy"]).model_dump()
        selected = set(names)
        known = {table["name"]: table for table in self.inventory(workspace_id)}
        if selected - known.keys():
            raise ValueError("Some selected tables are missing; refresh metadata")
        tables = [self.assess(known[name], policy) for name in sorted(selected)]
        eligible = [table for table in tables if table["eligible"]]
        if not eligible:
            raise ValueError("No eligible tables. Refresh inventory or review the maintenance policy.")
        plan = {"id": uid(), "workspace_id": workspace_id, "created_at": now(),
            "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=15)).isoformat(),
            "workspace_revision": workspace["updated_at"], "policy": policy,
            "tables": eligible, "skipped": [table for table in tables if not table["eligible"]],
            "input_bytes": sum(t["bytes"] for t in eligible),
            "small_files": sum(t["small_files"] for t in eligible),
            "sql": ";\n\n".join(sql_for(t["name"], policy) for t in eligible) + ";"}
        self.db.execute("INSERT INTO plans(id,workspace_id,data) VALUES(?,?,?)", (plan["id"], workspace_id, pack(plan)))
        return plan

    def _new_run(self, workspace, kind, tables, policy, schedule=None, occurrence=None):
        run_id = uid()
        manifest = {"run_id": run_id, "kind": kind, "policy": policy, "tables": tables,
            "timeout_minutes": workspace["execution_timeout_minutes"],
            "result_uri": f"s3://{workspace['bucket']}/{workspace['prefix'].strip('/')}/results/{run_id}.json"}
        return {"id": run_id, "workspace_id": workspace["id"], "workspace": workspace,
            "kind": kind, "state": "SUBMITTING", "job_id": None, "created_at": now(),
            "updated_at": now(), "manifest": manifest, "schedule_id": schedule["id"] if schedule else None,
            "schedule": schedule, "occurrence": occurrence, "attempts": 0, "last_poll": 0,
            "error": None, "cancel_requested": False, "needs_result": False,
            "script": (ROOT / "jobs" / "iceberg_job.py").read_text()}

    @staticmethod
    def _insert_run(con, run):
        try:
            con.execute("INSERT INTO runs(id,workspace_id,kind,state,job_id,schedule_id,occurrence,data) VALUES(?,?,?,?,?,?,?,?)",
                (run["id"], run["workspace_id"], run["kind"], run["state"], run["job_id"], run["schedule_id"], run["occurrence"], pack(run)))
        except sqlite3.IntegrityError:
            raise Conflict("A job is already active in this workspace, or this scheduled occurrence was already submitted") from None

    def scan(self, workspace_id, schedule=None, occurrence=None):
        workspace = self.workspace(workspace_id)
        self.gateway.ready(workspace)
        policy = schedule["policy"] if schedule else workspace["policy"]
        run = self._new_run(workspace, "inventory", [], policy, schedule, occurrence)
        with self.db.transaction() as con:
            self._insert_run(con, run)
        self.event(workspace_id, "Metadata scan queued for " + ("local Spark" if workspace.get("backend") == "local" else "AWS submission"))
        return self.public_run(run)

    def start_plan(self, workspace_id, plan_id, approved, schedule=None, occurrence=None):
        if not approved:
            raise ValueError("Approve this plan before submitting an AWS maintenance job")
        workspace = self.workspace(workspace_id)
        with self.db.transaction() as con:
            row = con.execute("SELECT * FROM plans WHERE id=? AND workspace_id=?", (plan_id, workspace_id)).fetchone()
            if not row:
                raise KeyError("Plan not found")
            plan = unpack(row)
            # Repeating the request returns its original job, never a second job.
            if row["consumed"]:
                for row in con.execute("SELECT data FROM runs WHERE workspace_id=?", (workspace_id,)):
                    existing = unpack(row)
                    if existing.get("plan_id") == plan_id:
                        return self.public_run(existing)
                raise Conflict("Plan was already submitted")
            if plan["expires_at"] <= now() or plan["workspace_revision"] != workspace["updated_at"]:
                raise Conflict("Plan expired or configuration changed; review a new plan")
            inventory = {row["name"]: unpack(row) for row in con.execute("SELECT * FROM inventory WHERE workspace_id=?", (workspace_id,))}
            for table in plan["tables"]:
                current = inventory.get(table["name"])
                if not current or current.get("snapshot_id") != table["snapshot_id"] or not self.assess(current, plan["policy"])["eligible"]:
                    raise Conflict("Table metadata or eligibility changed; review a new plan")
            run = self._new_run(workspace, "maintenance", [{"name": t["name"], "snapshot_id": t["snapshot_id"]} for t in plan["tables"]], plan["policy"], schedule, occurrence)
            run["plan_id"] = plan_id
            self._insert_run(con, run)
            con.execute("UPDATE plans SET consumed=1 WHERE id=?", (plan_id,))
        self.event(workspace_id, "Approved maintenance plan queued for " + ("local Spark" if workspace.get("backend") == "local" else "AWS submission"))
        return self.public_run(run)

    def raw_run(self, run_id):
        rows = self.db.rows("SELECT data FROM runs WHERE id=?", (run_id,))
        if not rows:
            raise KeyError("Run not found")
        return unpack(rows[0])

    @staticmethod
    def public_run(run):
        return {k: v for k, v in run.items() if k not in {"script", "workspace", "schedule"}}

    def runs(self, workspace_id):
        return [self.public_run(unpack(row)) for row in self.db.rows("SELECT data FROM runs WHERE workspace_id=? ORDER BY rowid DESC LIMIT 100", (workspace_id,))]

    def save_run(self, run):
        run["updated_at"] = now()
        with self.db.transaction() as con:
            row = con.execute("SELECT data FROM runs WHERE id=?", (run["id"],)).fetchone()
            if row and unpack(row).get("cancel_requested"):
                run["cancel_requested"] = True
                if run["state"] in ACTIVE:
                    run["state"] = "CANCELLING"
            con.execute("UPDATE runs SET state=?,job_id=?,data=? WHERE id=?", (run["state"], run["job_id"], pack(run), run["id"]))

    def cancel(self, workspace_id, run_id):
        with self.db.transaction() as con:
            row = con.execute("SELECT data FROM runs WHERE id=? AND workspace_id=?", (run_id, workspace_id)).fetchone()
            if not row:
                raise KeyError("Run not found")
            run = unpack(row)
            if run["state"] not in ACTIVE:
                raise Conflict("This job has already ended")
            run["cancel_requested"] = True
            if not run["job_id"] and not run["attempts"]:
                run["state"] = "CANCELLED"
            else:
                run["state"] = "CANCELLING"
            run["updated_at"] = now()
            con.execute("UPDATE runs SET state=?,data=? WHERE id=?", (run["state"], pack(run), run_id))
        self.event(workspace_id, "Cancellation requested for " + run_id)
        return self.public_run(run)

    def schedules(self, workspace_id):
        return [unpack(row) for row in self.db.rows("SELECT data FROM schedules WHERE workspace_id=? ORDER BY rowid DESC", (workspace_id,))]

    def save_schedule(self, workspace_id, model: Schedule, schedule_id=None):
        workspace = self.workspace(workspace_id)
        if model.enabled:
            self.gateway.ready(workspace)
        old = None
        if schedule_id:
            rows = self.db.rows("SELECT data FROM schedules WHERE id=? AND workspace_id=?", (schedule_id, workspace_id))
            if not rows:
                raise KeyError("Schedule not found")
            old = unpack(rows[0])
        next_at = next_occurrences(model.expression, model.timezone, 1)[0]
        data = {**model.model_dump(), "name": model.name.strip(), "id": schedule_id or uid(),
            "workspace_id": workspace_id, "next_at": next_at, "updated_at": now(),
            "created_at": old["created_at"] if old else now(), "last_error": None,
            "last_started_at": old.get("last_started_at") if old else None}
        self.db.execute("INSERT OR REPLACE INTO schedules(id,workspace_id,next_at,enabled,data) VALUES(?,?,?,?,?)",
            (data["id"], workspace_id, next_at, int(data["enabled"]), pack(data)))
        self.event(workspace_id, "Schedule saved: " + data["name"])
        return data

    def delete_schedule(self, workspace_id, schedule_id):
        self.db.execute("DELETE FROM schedules WHERE id=? AND workspace_id=?", (schedule_id, workspace_id))
        self.event(workspace_id, "Schedule deleted")


class Engine:
    """One durable scheduler/monitor; SQLite and AWS idempotency survive restarts."""
    def __init__(self, service):
        self.service = service
        self.stop_event = threading.Event()
        self.thread = None
        self.tick_lock = threading.RLock()
        self.worker_lock = None

    def start(self):
        import fcntl
        self.worker_lock = open(self.service.db.path.with_suffix(".worker.lock"), "a+")
        try:
            fcntl.flock(self.worker_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.worker_lock.close()
            raise RuntimeError("Another Iceberg Ops backend owns this database. Use one server worker.") from None
        self.thread = threading.Thread(target=self.loop, name="iceberg-ops-worker", daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=40)
        if self.worker_lock:
            self.worker_lock.close()

    def loop(self):
        while not self.stop_event.is_set():
            try:
                self.tick()
            except Exception as error:
                self.service.event(None, "Worker error: " + error_message(error))
            self.stop_event.wait(2)

    def tick(self):
        with self.tick_lock:
            service = self.service
            rows = service.db.rows("SELECT data FROM runs WHERE state IN (" + ",".join("?" * len(ACTIVE)) + ") OR json_extract(data,'$.needs_result')=1 OR (state='SUCCESS' AND kind='inventory' AND json_extract(data,'$.schedule_id') IS NOT NULL AND coalesce(json_extract(data,'$.followup_done'),0)=0)", ACTIVE)
            for row in rows:
                if self.stop_event.is_set():
                    return
                self.process(unpack(row))
            self.due_schedules()

    def process(self, run):
        service, gateway = self.service, self.service.gateway
        if time.time() - run["last_poll"] < (30 if run.get("error") else 8):
            return
        run["last_poll"] = time.time()
        try:
            if not run["job_id"]:
                # Record intent before any network call; an uncertain response retries the same token.
                run["attempts"] += 1
                service.save_run(run)
                if not run.get("discovered") and run["kind"] == "inventory":
                    run["manifest"]["tables"] = gateway.discover(run["workspace"])
                    run["discovered"] = True
                    service.save_run(run)
                run["job_id"] = gateway.submit(run["workspace"], run)
                run["state"], run["error"] = "SUBMITTED", None
                service.save_run(run)
                executor = "Local Spark" if run["workspace"].get("backend") == "local" else "AWS"
                service.event(run["workspace_id"], f"{executor} accepted {run['kind']} job {run['job_id']}")
            # Merge cancellation arriving during a slow AWS request.
            fresh = service.raw_run(run["id"])
            run["cancel_requested"] = fresh["cancel_requested"]
            if run["cancel_requested"] and run["state"] in ACTIVE:
                gateway.cancel(run["workspace"], run["job_id"])
            job = gateway.poll(run["workspace"], run["job_id"])
            run["state"] = job["state"]
            run["details"] = job.get("stateDetails", "")
            run["usage"] = job.get("billedResourceUtilization", job.get("totalResourceUtilization"))
            run["duration_seconds"] = job.get("totalExecutionDurationSeconds")
            run["error"] = None
            if run["state"] in {"SUCCESS", "FAILED", "CANCELLED"}:
                run["finished_at"] = str(job.get("updatedAt") or now())
                if not run.get("result_imported"):
                    run["needs_result"] = True
                    if not run.get("terminal_seen_at"):
                        run["terminal_seen_at"] = time.time()
                    try:
                        result = gateway.result(run["workspace"], run)
                        self.import_result(run, result)
                    except Exception as error:
                        run["result_error"] = error_message(error)
                        # Cancelled jobs may never produce a result; never invent successful work.
                        if run["state"] != "SUCCESS" or time.time() - run["terminal_seen_at"] > 300:
                            run["needs_result"] = False
                            self.invalidate(run)
                        service.save_run(run)
                        return
                if run["kind"] == "inventory" and run["state"] == "SUCCESS" and run.get("schedule") and not run.get("followup_done"):
                    # Save terminal state before the next run claims the workspace lock.
                    service.save_run(run)
                    self.schedule_followup(run)
            service.save_run(run)
        except Exception as error:
            message = error_message(error)
            run["error"] = message
            # Validation/auth errors are definite non-submissions; transport errors remain retryable.
            code = error.response.get("Error", {}).get("Code", "") if isinstance(error, ClientError) else ""
            permanent = isinstance(error, ValueError) or type(error).__name__ in {"NoCredentialsError", "ProfileNotFound", "SSOTokenLoadError", "UnauthorizedSSOTokenError"} or code in {"AccessDeniedException", "AccessDenied", "ValidationException", "ResourceNotFoundException", "InvalidRequestException"}
            if not run["job_id"] and permanent:
                run["state"], run["finished_at"] = "FAILED", now()
            service.save_run(run)
            service.event(run["workspace_id"], message)

    def invalidate(self, run):
        if run["kind"] != "maintenance":
            return
        names = {t["name"] for t in run["manifest"]["tables"]}
        for table in self.service.inventory(run["workspace_id"]):
            if table["name"] in names:
                table["error"] = "Maintenance ended without a complete result. Refresh metadata before replanning."
                self.service.db.execute("UPDATE inventory SET data=? WHERE workspace_id=? AND name=?", (pack(table), run["workspace_id"], table["name"]))

    def import_result(self, run, result):
        if result.get("run_id") != run["id"] or result.get("kind") != run["kind"]:
            raise ValueError("Job result identity does not match this run")
        expected = {t if isinstance(t, str) else t["name"] for t in run["manifest"]["tables"]}
        received = {t["name"] for t in result["tables"]}
        if not received <= expected:
            raise ValueError("Job result contains tables outside its approved scope")
        service = self.service
        previous = {t["name"]: t for t in service.inventory(run["workspace_id"])}
        successful = {a["name"] for a in result.get("actions", []) if a["status"] == "SUCCESS"}
        measured = {t["name"]: t for t in result["tables"]}
        with service.db.transaction() as con:
            if run["kind"] == "inventory" and run["state"] == "SUCCESS":
                con.execute("DELETE FROM inventory WHERE workspace_id=?", (run["workspace_id"],))
            for name in expected:
                item = measured.get(name, {"name": name, "error": "No result for this table; refresh metadata"})
                record = {**previous.get(name, {}), **item}
                if name in successful and run["kind"] == "maintenance":
                    record["last_maintenance_at"] = result.get("finished_at", now())
                con.execute("INSERT OR REPLACE INTO inventory(workspace_id,name,data) VALUES(?,?,?)", (run["workspace_id"], name, pack(record)))
            run["result"], run["result_imported"], run["needs_result"] = result, True, False
            run["result_error"] = None
            con.execute("UPDATE runs SET state=?,job_id=?,data=? WHERE id=?", (run["state"], run["job_id"], pack(run), run["id"]))
        service.event(run["workspace_id"], f"{run['kind'].capitalize()} job {run['state']}; measured results saved")

    def schedule_followup(self, run):
        service = self.service
        schedule = run["schedule"]
        current = next((s for s in service.schedules(run["workspace_id"]) if s["id"] == schedule["id"]), None)
        try:
            if not current or not current["enabled"] or current["updated_at"] != schedule["updated_at"]:
                service.event(run["workspace_id"], "Scheduled maintenance stopped because the schedule was paused, edited, or deleted")
            else:
                names = [t["name"] for t in service.inventory(run["workspace_id"])] if schedule["scope"] == "auto" else schedule["tables"]
                plan = service.make_plan(run["workspace_id"], names, schedule["policy"])
                service.start_plan(run["workspace_id"], plan["id"], True, schedule, run["occurrence"])
        except ValueError as error:
            service.event(run["workspace_id"], "Scheduled maintenance skipped: " + error_message(error))
        run["followup_done"] = True

    def due_schedules(self):
        service = self.service
        for row in service.db.rows("SELECT data FROM schedules WHERE enabled=1 AND next_at<=?", (now(),)):
            schedule = unpack(row)
            due = schedule["next_at"]
            message = None
            try:
                if datetime.fromisoformat(due) < datetime.now(timezone.utc) - timedelta(seconds=60):
                    message = "Missed occurrence skipped; the backend was unavailable. The next occurrence is scheduled."
                else:
                    service.scan(schedule["workspace_id"], schedule, due)
                    schedule["last_started_at"] = now()
            except Exception as error:
                message = error_message(error)
            schedule["last_error"] = message
            schedule["next_at"] = next_occurrences(schedule["expression"], schedule["timezone"], 1)[0]
            service.db.execute("UPDATE schedules SET next_at=?,data=? WHERE id=? AND next_at=?", (schedule["next_at"], pack(schedule), schedule["id"], due))
            if message:
                service.event(schedule["workspace_id"], message)
