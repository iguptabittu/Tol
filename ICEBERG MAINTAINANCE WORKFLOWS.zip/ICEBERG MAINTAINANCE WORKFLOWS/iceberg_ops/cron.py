"""Five-field cron with IANA timezone/DST support, without minute-by-minute scans."""
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import re


class CronError(ValueError):
    pass


def field(text, low, high, weekday=False):
    values = set()
    for item in text.split(","):
        match = re.fullmatch(r"(\*|\d+(?:-\d+)?)(?:/(\d+))?", item)
        if not match:
            raise CronError(f"Invalid cron field: {text}")
        base, step = match.groups()
        step = int(step or 1)
        if step < 1:
            raise CronError("Cron steps must be positive integers")
        if base == "*":
            start, end = low, high
        elif "-" in base:
            start, end = map(int, base.split("-"))
        else:
            start = int(base)
            end = high if match.group(2) is not None else start
        if not low <= start <= end <= high:
            raise CronError(f"Cron values must be between {low} and {high}")
        values.update(0 if weekday and n == 7 else n for n in range(start, end + 1, step))
    return values


def next_occurrences(expression, zone="UTC", count=5, after=None):
    parts = expression.split()
    if len(parts) != 5:
        raise CronError("Use five fields: minute hour day month weekday")
    minute, hour, dom, month, dow = [field(t, lo, hi, wd) for t, lo, hi, wd in zip(
        parts, (0, 0, 1, 1, 0), (59, 23, 31, 12, 7), (False, False, False, False, True))]
    try:
        tz = ZoneInfo(zone)
    except (ZoneInfoNotFoundError, ValueError):
        raise CronError("Choose a valid IANA timezone") from None
    after = after or datetime.now(timezone.utc)
    if after.tzinfo is None:
        raise CronError("The reference time must include a timezone")
    after = after.astimezone(timezone.utc)
    day = after.astimezone(tz).date()
    result = []
    # Allow eight years per occurrence (including a non-leap century).
    for offset in range(366 * 8 * count + 1):
        if offset > 366 * 8 and not result:
            break
        date = day + timedelta(days=offset)
        if date.month not in month:
            continue
        dom_ok, dow_ok = date.day in dom, (date.weekday() + 1) % 7 in dow
        wild_dom, wild_dow = parts[2].startswith("*"), parts[4].startswith("*")
        day_ok = (dom_ok and dow_ok) if wild_dom or wild_dow else (dom_ok or dow_ok)
        if not day_ok:
            continue
        candidates = set()
        for hh in sorted(hour):
            for mm in sorted(minute):
                naive = datetime(date.year, date.month, date.day, hh, mm)
                for fold in (0, 1):
                    utc = naive.replace(tzinfo=tz, fold=fold).astimezone(timezone.utc)
                    # A spring-forward wall time does not round-trip. Dedup ordinary times.
                    if utc.astimezone(tz).replace(tzinfo=None) == naive and utc > after:
                        candidates.add(utc)
        result.extend(sorted(candidates))
        if len(result) >= count:
            return [d.isoformat() for d in result[:count]]
    raise CronError("This cron has no occurrences in the next eight years")
