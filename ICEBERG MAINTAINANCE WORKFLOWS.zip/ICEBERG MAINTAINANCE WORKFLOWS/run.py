"""Run from the project directory: python3 run.py"""
import argparse
import os
import uvicorn
from iceberg_ops.api import create_app


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Start the local Iceberg Ops console")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--db", help="SQLite database path")
    args = parser.parse_args()
    print(f"Iceberg Ops: http://127.0.0.1:{args.port}", flush=True)
    uvicorn.run(create_app(args.db), host="127.0.0.1", port=args.port, workers=1, log_level="info")
