"""Validate submission request shapes against the installed AWS SDK, without network."""
from contextlib import ExitStack
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

import boto3
from botocore.stub import Stubber, ANY
from iceberg_ops.aws import AWSGateway
from iceberg_ops.service import Service
from test_app import workspace_model


class AWSAdapterTests(unittest.TestCase):
    def test_real_sdk_accepts_submission_and_configures_iceberg(self):
        session = boto3.Session(region_name="ap-south-1", aws_access_key_id="testing",
            aws_secret_access_key="testing", aws_session_token="testing")
        clients = {name: session.client(name) for name in ("sts", "s3", "emr-serverless")}
        gateway = AWSGateway()
        class Router:
            def client(self, name, **kwargs):
                return clients[name]
        gateway.session = lambda workspace: Router()
        with TemporaryDirectory() as temporary:
            service = Service(Path(temporary)/"ops.sqlite3", gateway)
            workspace = service.save_workspace(workspace_model())
            run = service.raw_run(service.scan(workspace["id"])["id"])
            with ExitStack() as stack:
                stubs = {name: stack.enter_context(Stubber(client)) for name, client in clients.items()}
                stubs["sts"].add_response("get_caller_identity", {
                    "UserId": "test-user", "Account": "123456789012",
                    "Arn": "arn:aws:iam::123456789012:user/test"})
                for _ in range(2):
                    stubs["s3"].add_response("put_object", {}, {"Bucket": "test-operations-bucket",
                        "Key": ANY, "Body": ANY, "ServerSideEncryption": "AES256"})
                recorded = []
                def record_request(params, **kwargs):
                    recorded.append(params)
                clients["emr-serverless"].meta.events.register("before-parameter-build.emr-serverless.StartJobRun", record_request)
                stubs["emr-serverless"].add_response("start_job_run", {
                    "applicationId": "app123", "jobRunId": "job123",
                    "arn": "arn:aws:emr-serverless:ap-south-1:123456789012:/applications/app123/jobruns/job123"})
                self.assertEqual(gateway.submit(workspace, run), "job123")
                params = recorded[0]
                self.assertEqual(params["clientToken"], run["id"])
                self.assertEqual(params["executionTimeoutMinutes"], 60)
                config = params["jobDriver"]["sparkSubmit"]["sparkSubmitParameters"]
                self.assertIn("spark.sql.catalog.ops.glue.id=123456789012", config)
                self.assertIn("maxExecutors=4", config)
                for stub in stubs.values():
                    stub.assert_no_pending_responses()


if __name__ == "__main__":
    unittest.main()
