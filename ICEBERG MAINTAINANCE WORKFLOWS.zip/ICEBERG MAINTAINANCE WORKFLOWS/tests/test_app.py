from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import unittest

from fastapi.testclient import TestClient
from iceberg_ops.api import create_app
from iceberg_ops.aws import AWSGateway
from iceberg_ops.cron import next_occurrences, CronError
from iceberg_ops.database import pack
from iceberg_ops.models import Workspace, Policy, Schedule
from iceberg_ops.service import Service, Engine, Conflict, now
from jobs.iceberg_job import sql_for, validate_name


def workspace_model(**kwargs):
    return Workspace(name="Test workspace", account_id="123456789012", region="ap-south-1",
        application_id="app123", execution_role_arn="arn:aws:iam::123456789012:role/IcebergOps",
        bucket="test-operations-bucket", warehouse="s3://test-data-bucket/warehouse/",
        databases=["analytics"], **kwargs)


def table(name="analytics.events", snapshot="100"):
    return {"name": name, "snapshot_id": snapshot, "scanned_at": now(),
        "file_count": 20, "small_files": 16, "small_mb": 128, "bytes": 1073741824,
        "partitions": 4, "error": None}


class FakeAWS:
    ready = staticmethod(AWSGateway.ready)

    def __init__(self):
        self.submissions = []
        self.state = "SUCCESS"
        self.cancelled = []
        self.fail_submission_once = False

    def check(self, workspace):
        self.ready(workspace)
        return {"account_id": workspace["account_id"], "principal": "test-principal", "application_state": "STOPPED", "release": "emr-7.12.0"}

    def discover(self, workspace):
        return ["analytics.events", "analytics.orders"]

    def submit(self, workspace, run):
        if run["id"] not in self.submissions:
            self.submissions.append(run["id"])
        if self.fail_submission_once:
            self.fail_submission_once = False
            raise TimeoutError("Response lost after AWS accepted request")
        return "job" + str(self.submissions.index(run["id"]) + 1)

    def poll(self, workspace, job_id):
        return {"state": "CANCELLED" if job_id in self.cancelled else self.state,
            "updatedAt": now(), "billedResourceUtilization": {"vCPUHour": .01, "memoryGBHour": .04}}

    def result(self, workspace, run):
        records, actions = [], []
        for item in run["manifest"]["tables"]:
            name = item if isinstance(item, str) else item["name"]
            record = table(name)
            if run["kind"] == "maintenance":
                record.update(file_count=2, small_files=0, snapshot_id="101")
                actions.append({"name": name, "status": "SUCCESS", "output": [{"rewritten_data_files_count": 20, "added_data_files_count": 2}]})
            records.append(record)
        return {"run_id": run["id"], "kind": run["kind"], "tables": records, "actions": actions, "finished_at": now()}

    def cancel(self, workspace, job_id):
        self.cancelled.append(job_id)

    def logs(self, workspace, job_id):
        return "Measured test driver log"


class CronTests(unittest.TestCase):
    def test_does_not_skip_next_minute(self):
        self.assertEqual(next_occurrences("0 * * * *", "UTC", 1, datetime(2026, 10, 31, 12, 59, 30, tzinfo=timezone.utc)), ["2026-10-31T13:00:00+00:00"])

    def test_leap_day(self):
        result = next_occurrences("0 2 29 2 *", "UTC", 1, datetime(2026, 10, 31, tzinfo=timezone.utc))
        self.assertEqual(result, ["2028-02-29T02:00:00+00:00"])

    def test_fractional_timezone_offset(self):
        result = next_occurrences("0 2 * * *", "Asia/Kolkata", 1, datetime(2026, 10, 31, 12, tzinfo=timezone.utc))
        self.assertEqual(result, ["2026-10-31T20:30:00+00:00"])

    def test_spring_dst_skips_missing_time(self):
        result = next_occurrences("30 2 * * *", "America/New_York", 1, datetime(2027, 3, 14, 5, tzinfo=timezone.utc))
        self.assertEqual(result, ["2027-03-15T06:30:00+00:00"])

    def test_fall_dst_includes_both_folds(self):
        result = next_occurrences("30 1 * * *", "America/New_York", 2, datetime(2026, 11, 1, 4, tzinfo=timezone.utc))
        self.assertEqual(result, ["2026-11-01T05:30:00+00:00", "2026-11-01T06:30:00+00:00"])

    def test_day_or_and_wildcard_semantics(self):
        after = datetime(2026, 10, 31, 12, tzinfo=timezone.utc)
        self.assertEqual(next_occurrences("0 0 1 * 1", "UTC", 2, after), ["2026-11-01T00:00:00+00:00", "2026-11-02T00:00:00+00:00"])
        self.assertEqual(next_occurrences("0 0 */2 * 1", "UTC", 1, after), ["2026-11-09T00:00:00+00:00"])

    def test_invalid_dates_and_fields(self):
        for expression in ("* * *", "61 * * * *", "*/0 * * * *", "0 0 31 2 *", "0 0 * * MON"):
            with self.subTest(expression=expression), self.assertRaises(CronError):
                next_occurrences(expression)


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.path = Path(self.temp.name) / "ops.sqlite3"
        self.aws = FakeAWS()
        self.service = Service(self.path, self.aws)
        self.ws = self.service.save_workspace(workspace_model())
        self.id = self.ws["id"]
        self.engine = Engine(self.service)

    def tearDown(self):
        self.temp.cleanup()

    def seed(self, record=None):
        record = record or table()
        self.service.db.execute("INSERT OR REPLACE INTO inventory(workspace_id,name,data) VALUES(?,?,?)", (self.id, record["name"], pack(record)))

    def force_poll(self, run_id):
        run = self.service.raw_run(run_id)
        run["last_poll"] = 0
        self.service.save_run(run)
        self.engine.tick()

    def test_persistence_and_real_result_import(self):
        run = self.service.scan(self.id)
        self.engine.tick()
        self.assertEqual(self.service.raw_run(run["id"])["state"], "SUCCESS")
        self.assertEqual(len(Service(self.path, self.aws).inventory(self.id)), 2)
        plan = self.service.make_plan(self.id, ["analytics.events"])
        maintenance = self.service.start_plan(self.id, plan["id"], True)
        self.engine.tick()
        measured = next(t for t in self.service.inventory(self.id) if t["name"] == "analytics.events")
        self.assertEqual(measured["file_count"], 2)
        self.assertIsNotNone(measured["last_maintenance_at"])
        self.assertTrue(self.service.raw_run(maintenance["id"])["result_imported"])

    def test_approval_and_idempotence(self):
        self.seed()
        plan = self.service.make_plan(self.id, ["analytics.events"])
        with self.assertRaises(ValueError):
            self.service.start_plan(self.id, plan["id"], False)
        first = self.service.start_plan(self.id, plan["id"], True)
        self.assertEqual(first["id"], self.service.start_plan(self.id, plan["id"], True)["id"])

    def test_no_overlapping_jobs_or_connection_edits(self):
        self.service.scan(self.id)
        with self.assertRaises(Conflict):
            self.service.scan(self.id)
        with self.assertRaises(Conflict):
            self.service.save_workspace(workspace_model(), self.id)

    def test_stale_snapshot_or_expired_inventory_rejected(self):
        self.seed()
        plan = self.service.make_plan(self.id, ["analytics.events"])
        self.seed(table(snapshot="200"))
        with self.assertRaises(Conflict):
            self.service.start_plan(self.id, plan["id"], True)
        expired = table()
        expired["scanned_at"] = (datetime.now(timezone.utc) - timedelta(days=2)).isoformat()
        self.seed(expired)
        with self.assertRaises(ValueError):
            self.service.make_plan(self.id, ["analytics.events"])

    def test_group_limit_is_in_generated_sql(self):
        self.seed()
        policy = Policy(max_group_gb=2).model_dump()
        plan = self.service.make_plan(self.id, ["analytics.events"], policy)
        self.assertIn("'max-file-group-size-bytes', '2147483648'", plan["sql"])
        self.assertNotIn("rewrite-all", plan["sql"])

    def test_uncertain_submission_retries_same_token_after_restart(self):
        self.aws.fail_submission_once = True
        run = self.service.scan(self.id)
        self.engine.tick()
        self.assertEqual(self.service.raw_run(run["id"])["state"], "SUBMITTING")
        self.service = Service(self.path, self.aws)
        self.engine = Engine(self.service)
        self.force_poll(run["id"])
        self.assertEqual(self.service.raw_run(run["id"])["state"], "SUCCESS")
        self.assertEqual(self.aws.submissions, [run["id"]])

    def test_cancel_before_submission(self):
        run = self.service.scan(self.id)
        self.service.cancel(self.id, run["id"])
        self.engine.tick()
        self.assertEqual(self.service.raw_run(run["id"])["state"], "CANCELLED")
        self.assertEqual(self.aws.submissions, [])

    def test_cancel_accepted_job(self):
        self.aws.state = "RUNNING"
        run = self.service.scan(self.id)
        self.engine.tick()
        self.service.cancel(self.id, run["id"])
        self.force_poll(run["id"])
        self.assertEqual(self.service.raw_run(run["id"])["state"], "CANCELLED")
        self.assertEqual(self.aws.cancelled, ["job1"])

    def test_cancellation_during_submission_is_preserved(self):
        real_submit = self.aws.submit
        def submit(workspace, run):
            self.service.cancel(self.id, run["id"])
            return real_submit(workspace, run)
        self.aws.submit = submit
        run = self.service.scan(self.id)
        self.engine.tick()
        self.assertEqual(self.service.raw_run(run["id"])["state"], "CANCELLED")

    def test_schedule_rename_retains_independent_scope_and_policy(self):
        original = self.service.save_schedule(self.id, Schedule(name="Events", expression="0 2 * * *", scope="selected", tables=["analytics.events"], policy=Policy(max_group_gb=2)))
        model = Schedule.model_validate({k: original[k] for k in Schedule.model_fields})
        model.name = "Renamed"
        updated = self.service.save_schedule(self.id, model, original["id"])
        self.assertEqual(updated["tables"], ["analytics.events"])
        self.assertEqual(updated["policy"]["max_group_gb"], 2)

    def due(self, schedule, seconds=1):
        schedule["next_at"] = (datetime.now(timezone.utc) - timedelta(seconds=seconds)).isoformat()
        self.service.db.execute("UPDATE schedules SET next_at=?,data=? WHERE id=?", (schedule["next_at"], pack(schedule), schedule["id"]))

    def test_schedule_refreshes_metadata_then_compacts(self):
        schedule = self.service.save_schedule(self.id, Schedule(name="Automatic", expression="0 2 * * *", enabled=True, approved=True))
        self.due(schedule)
        self.engine.tick()  # due occurrence queues scan
        self.engine.tick()  # scan succeeds, follow-up queued
        self.engine.tick()  # follow-up succeeds
        runs = self.service.runs(self.id)
        self.assertEqual([r["kind"] for r in runs], ["maintenance", "inventory"])
        self.assertTrue(all(r["state"] == "SUCCESS" for r in runs))
        self.assertEqual(len(self.aws.submissions), 2)

    def test_pause_prevents_scan_followup(self):
        schedule = self.service.save_schedule(self.id, Schedule(name="Automatic", expression="0 2 * * *", enabled=True, approved=True))
        self.due(schedule)
        self.engine.tick()
        model = Schedule.model_validate({k: schedule[k] for k in Schedule.model_fields})
        model.enabled = False
        self.service.save_schedule(self.id, model, schedule["id"])
        self.engine.tick()
        self.assertEqual(len(self.service.runs(self.id)), 1)

    def test_missed_occurrence_skipped_and_recorded(self):
        schedule = self.service.save_schedule(self.id, Schedule(name="Automatic", expression="0 2 * * *", enabled=True, approved=True))
        self.due(schedule, 3600)
        self.engine.tick()
        self.assertEqual(self.service.runs(self.id), [])
        self.assertIn("Missed occurrence", self.service.schedules(self.id)[0]["last_error"])

    def test_target_change_pauses_schedules_and_invalidates_inventory(self):
        self.seed()
        self.service.save_schedule(self.id, Schedule(name="Automatic", expression="0 2 * * *", enabled=True, approved=True))
        updated = workspace_model()
        updated.application_id = "differentapp"
        self.service.save_workspace(updated, self.id)
        self.assertFalse(self.service.schedules(self.id)[0]["enabled"])
        self.assertEqual(self.service.inventory(self.id), [])

    def test_foreign_result_cannot_import(self):
        run = self.service.scan(self.id)
        raw = self.service.raw_run(run["id"])
        with self.assertRaises(ValueError):
            self.engine.import_result(raw, {"run_id": "wrong", "kind": "inventory", "tables": []})


class APITests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.app = create_app(Path(self.temp.name)/"ops.sqlite3", FakeAWS(), worker=False)
        self.client = TestClient(self.app)
        self.headers = {"X-Ops-Request": "1"}

    def tearDown(self):
        self.client.close()
        self.temp.cleanup()

    def test_empty_start_and_static_app(self):
        self.assertEqual(self.client.get("/api/system").json()["workspaces"], [])
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("script-src 'self'", response.headers["Content-Security-Policy"])

    def test_cross_origin_and_dns_rebinding_blocked(self):
        body = workspace_model().model_dump()
        self.assertEqual(self.client.post("/api/workspaces", json=body).status_code, 403)
        self.assertEqual(self.client.post("/api/workspaces", json=body, headers={**self.headers, "Origin": "https://evil.example"}).status_code, 403)
        self.assertEqual(self.client.get("/api/system", headers={"Host": "evil.example"}).status_code, 400)

    def test_workspace_api_and_scan(self):
        response = self.client.post("/api/workspaces", json=workspace_model().model_dump(), headers=self.headers)
        self.assertEqual(response.status_code, 201)
        workspace_id = response.json()["id"]
        prefix = "/api/workspaces/" + workspace_id
        self.assertTrue(self.client.post(prefix+"/check", headers=self.headers).json()["ok"])
        self.assertEqual(self.client.post(prefix+"/scan", headers=self.headers).status_code, 202)
        self.app.state.engine.tick()
        self.assertEqual(len(self.client.get(prefix).json()["tables"]), 2)
        self.assertIn("inventory", self.client.get(prefix+"/history.csv").text)

    def test_invalid_policy_and_unknown_fields(self):
        body = workspace_model().model_dump()
        body["policy"]["small_mb"] = 1024
        self.assertEqual(self.client.post("/api/workspaces", json=body, headers=self.headers).status_code, 422)
        body = workspace_model().model_dump()
        body["access_key"] = "must-not-be-accepted"
        self.assertEqual(self.client.post("/api/workspaces", json=body, headers=self.headers).status_code, 422)

    def test_cron_error_response_and_leap_day(self):
        self.assertEqual(self.client.get("/api/cron", params={"expression": "0 0 31 2 *"}).status_code, 400)
        self.assertEqual(len(self.client.get("/api/cron", params={"expression": "0 0 29 2 *"}).json()["occurrences"]), 5)


class JobAndInfrastructureTests(unittest.TestCase):
    def test_sql_rejects_injection(self):
        for name in ("db.table; DROP TABLE x", "db.table'", "db.table.extra"):
            with self.assertRaises(ValueError):
                sql_for(name, Policy().model_dump())

    def test_template_is_regenerable_and_capacity_bounded(self):
        from tools.build_template import template
        saved = json.loads((Path(__file__).resolve().parents[1]/"infrastructure"/"cloudformation.json").read_text())
        self.assertEqual(template, saved)
        app = saved["Resources"]["Application"]["Properties"]
        self.assertEqual(app["MaximumCapacity"]["Cpu"], "16 vCPU")
        self.assertNotIn("InitialCapacity", app)


if __name__ == "__main__":
    unittest.main()
