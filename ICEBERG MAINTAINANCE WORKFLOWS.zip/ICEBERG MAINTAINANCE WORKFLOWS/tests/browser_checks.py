"""Optional browser acceptance test. Uses an isolated database and an AWS test adapter."""
import argparse
from pathlib import Path
import socket
import sys
from tempfile import TemporaryDirectory
import threading
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import uvicorn
from playwright.sync_api import sync_playwright, expect
from iceberg_ops.api import create_app
from test_app import FakeAWS


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--executable", help="Optional installed Chromium executable")
    parser.add_argument("--screenshots", default="/tmp/iceberg-ops-qa")
    parser.add_argument("--live-url", help="Read-only UI check and screenshots of an already running app")
    args = parser.parse_args()
    screenshots = Path(args.screenshots)
    screenshots.mkdir(parents=True, exist_ok=True)
    if args.live_url:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, **({"executable_path": args.executable} if args.executable else {}))
            page = browser.new_page(viewport={"width":1440,"height":1000})
            errors = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.goto(args.live_url)
            expect(page.locator("#connectionBadge")).to_have_text("LOCAL DOCKER CONNECTED")
            expect(page.locator("#tableRows tr")).to_have_count(2)
            page.screenshot(path=str(screenshots/"local-real-overview.png"), full_page=True)
            page.locator('[data-page="setup"]').click()
            expect(page.locator("#localSetupHelp")).to_be_visible()
            page.screenshot(path=str(screenshots/"local-real-setup.png"), full_page=True)
            page.locator('[data-page="runs"]').click()
            page.set_viewport_size({"width":390,"height":844})
            page.screenshot(path=str(screenshots/"local-real-mobile.png"), full_page=True)
            assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
            assert not errors, errors
            browser.close()
            print("Read-only real local UI check passed")
        return
    with TemporaryDirectory() as temporary:
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        app = create_app(Path(temporary)/"browser.sqlite3", FakeAWS())
        server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        for _ in range(100):
            if server.started:
                break
            time.sleep(.05)
        assert server.started, "Test server did not start"
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True, **({"executable_path": args.executable} if args.executable else {}))
                page = browser.new_page(viewport={"width": 1440, "height": 1050})
                errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))
                page.goto(f"http://127.0.0.1:{port}")
                page.locator("#backendState").get_by_text("Backend running", exact=True).wait_for()
                page.screenshot(path=str(screenshots/"overview-empty.png"), full_page=True)
                page.locator("#setupCTA").click()
                values = {"name":"Development · QA fixture", "account_id":"123456789012", "application_id":"app123", "execution_role_arn":"arn:aws:iam::123456789012:role/IcebergOps", "bucket":"test-operations-bucket", "warehouse":"s3://test-data-bucket/warehouse/", "databases":"analytics"}
                for key, value in values.items():
                    page.locator("#ws_"+key).fill(value)
                page.locator("#saveWorkspace").click()
                expect(page.locator("#testConnection")).to_be_enabled()
                page.locator("#testConnection").click()
                page.locator("#connectionResult").get_by_text("Connected:", exact=False).wait_for()
                page.locator('[data-page="home"]').click()
                page.locator("#scanMetadata").click()
                expect(page.locator(".run-card .pill").first).to_have_text("SUCCESS", timeout=20000)
                page.locator('[data-page="home"]').click()
                page.locator('[data-table="analytics.events"]').wait_for()
                page.screenshot(path=str(screenshots/"overview-live-fixture.png"), full_page=True)
                page.locator("#clearSelection").click()
                page.locator('[data-table="analytics.events"]').check()
                page.locator("#scheduleSelection").click()
                page.locator("#scheduleName").fill("Events only")
                page.locator("#schedulePreset").select_option("custom")
                page.locator("#scheduleCron").fill("0 2 29 2 *")
                page.locator("#saveSchedule").click()
                expect(page.locator("#scheduleDialog")).not_to_be_visible()
                page.locator("#clearSelection").click()
                page.locator('[data-table="analytics.orders"]').check()
                page.locator('[data-page="schedules"]').click()
                page.locator('[data-edit-schedule]').click()
                assert page.locator("#scheduleTables").evaluate("el=>[...el.selectedOptions].map(x=>x.value)") == ["analytics.events"]
                page.locator("#scheduleName").fill("Renamed events only")
                page.locator("#saveSchedule").click()
                expect(page.locator("#scheduleDialog")).not_to_be_visible()
                saved = app.state.service.schedules(app.state.service.workspaces()[0]["id"])[0]
                assert saved["tables"] == ["analytics.events"]
                assert saved["expression"] == "0 2 29 2 *"
                page.locator('[data-page="home"]').click()
                page.locator("#reviewPlan").click()
                page.locator("#planDialog").wait_for(state="visible")
                assert page.evaluate("document.getElementById('planDialog').contains(document.activeElement)")
                for _ in range(12):
                    page.keyboard.press("Tab")
                    assert page.evaluate("document.getElementById('planDialog').contains(document.activeElement)")
                page.locator("#planApproval").check()
                page.locator("#submitPlan").click()
                expect(page.locator(".run-card")).to_have_count(2, timeout=20000)
                expect(page.locator(".run-card .pill").first).to_have_text("SUCCESS", timeout=20000)
                page.screenshot(path=str(screenshots/"runs-desktop.png"), full_page=True)
                page.set_viewport_size({"width":390,"height":844})
                page.screenshot(path=str(screenshots/"runs-mobile.png"), full_page=True)
                assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), "Mobile page overflows"
                columns = page.locator(".run-layout").evaluate("el=>getComputedStyle(el).gridTemplateColumns")
                assert len(columns.split()) == 1, "Run layout must stack on mobile"
                page.locator('[data-page="setup"]').click()
                page.screenshot(path=str(screenshots/"setup-mobile.png"), full_page=True)
                assert not errors, errors
                browser.close()
                print("Browser checks passed: setup, scan, independent schedule edits, leap-day preview, modal focus, maintenance, responsive runs.")
                print("Screenshots:", screenshots)
        finally:
            server.should_exit = True
            thread.join(timeout=45)


if __name__ == "__main__":
    main()
