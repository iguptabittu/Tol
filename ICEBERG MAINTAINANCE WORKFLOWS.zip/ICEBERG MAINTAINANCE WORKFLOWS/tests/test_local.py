from unittest.mock import patch
import unittest

from iceberg_ops.models import Workspace
from iceberg_ops.local import LocalGateway, GatewayRouter


class LocalTests(unittest.TestCase):
    def test_local_workspace_has_no_aws_identity(self):
        workspace = Workspace(name="Local", backend="local")
        self.assertEqual(workspace.account_id, "")
        self.assertEqual(workspace.aws_profile, "")
        self.assertEqual(workspace.databases, ["analytics"])
        self.assertEqual(workspace.warehouse, "s3://warehouse/")

    def test_router_never_uses_aws_for_local_jobs(self):
        router = GatewayRouter()
        workspace = Workspace(name="Local", backend="local").model_dump()
        with patch.object(router.local, "check", return_value={"local": True}) as local, patch.object(router.aws, "check", side_effect=AssertionError("AWS must not be called")):
            self.assertEqual(router.check(workspace), {"local": True})
            local.assert_called_once_with(workspace)

    def test_local_startup_status_is_honest(self):
        gateway = LocalGateway()
        with patch.object(gateway, "request", return_value={"ready": False}):
            with self.assertRaisesRegex(ValueError, "preparing"):
                gateway.check(Workspace(name="Local", backend="local").model_dump())
