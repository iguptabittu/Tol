"""Uploaded verbatim to EMR. Reads manifests and writes measured results to S3."""
import json
import re
import sys
import os
from datetime import datetime, timezone
from urllib.parse import urlparse


def validate_name(name):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*", name):
        raise ValueError("Invalid table identifier")
    return name


def sql_for(name, policy):
    name = validate_name(name)
    options = {
        "target-file-size-bytes": str(int(policy["target_mb"]) * 1048576),
        "min-input-files": str(int(policy["min_files"])),
        "max-file-group-size-bytes": str(int(policy["max_group_gb"] * 1073741824)),
        "max-concurrent-file-group-rewrites": str(int(policy["parallel_groups"])),
        "partial-progress.enabled": "false",
    }
    pairs = ", ".join(f"'{key}', '{value}'" for key, value in options.items())
    return f"CALL ops.system.rewrite_data_files(table => '{name}', strategy => 'binpack', options => map({pairs}))"


def scan(spark, name, threshold):
    validate_name(name)
    full = "ops." + ".".join(f"`{bit}`" for bit in name.split("."))
    spark.catalog.refreshTable(full)
    # Java Iceberg API avoids assumptions about partition transforms or partition value types.
    table = spark._jvm.org.apache.iceberg.spark.Spark3Util.loadIcebergTable(spark._jsparkSession, "ops." + name)
    snapshot = table.currentSnapshot()
    # Read the current snapshot's live file manifests directly. This also avoids
    # REST servers interpreting a metadata-table suffix as a nested namespace.
    summary = {"file_count": 0, "bytes": 0, "small_files": 0}
    partitions = set()
    if snapshot:
        planned = table.newScan().useSnapshot(snapshot.snapshotId()).planFiles()
        try:
            iterator = planned.iterator()
            while iterator.hasNext():
                data_file = iterator.next().file()
                byte_count = data_file.fileSizeInBytes()
                summary["file_count"] += 1
                summary["bytes"] += byte_count
                summary["small_files"] += int(byte_count < threshold * 1048576)
                partitions.add(str(data_file.specId()) + ":" + data_file.partition().toString())
        finally:
            planned.close()
    summary["partitions"] = len(partitions)
    return {"name": name, **summary, "snapshot_id": str(snapshot.snapshotId()) if snapshot else None,
        "snapshot_at": datetime.fromtimestamp(snapshot.timestampMillis() / 1000, timezone.utc).isoformat() if snapshot else None,
        "scanned_at": datetime.now(timezone.utc).isoformat(), "small_mb": threshold, "error": None}


def main():
    import boto3
    from pyspark.sql import SparkSession
    s3 = boto3.client("s3")
    manifest_url = urlparse(sys.argv[1])
    manifest = json.loads(s3.get_object(Bucket=manifest_url.netloc, Key=manifest_url.path.lstrip("/"))["Body"].read())
    result_url = urlparse(manifest["result_uri"])
    spark = SparkSession.builder.appName("IcebergOps").getOrCreate()
    result = {"run_id": manifest["run_id"], "kind": manifest["kind"], "tables": [], "actions": []}
    failed = False
    for item in manifest["tables"]:
        name = item if isinstance(item, str) else item["name"]
        try:
            validate_name(name)
            if manifest["kind"] == "maintenance":
                current = scan(spark, name, manifest["policy"]["small_mb"])
                if current["snapshot_id"] != item["snapshot_id"]:
                    raise RuntimeError("Snapshot changed since review; refresh inventory and review a new plan")
                output = [row.asDict(recursive=True) for row in spark.sql(sql_for(name, manifest["policy"])).collect()]
                result["actions"].append({"name": name, "status": "SUCCESS", "output": output})
            measured = scan(spark, name, manifest["policy"]["small_mb"])
            result["tables"].append(measured)
            print(json.dumps({"table": name, "status": "SUCCESS", "files": measured["file_count"]}), flush=True)
        except Exception as error:
            failed = True
            result["actions"].append({"name": name, "status": "FAILED", "error": str(error)[:4000]})
            result["tables"].append({"name": name, "error": str(error)[:4000]})
            print(json.dumps({"table": name, "status": "FAILED", "error": str(error)[:4000]}), flush=True)
    result["finished_at"] = datetime.now(timezone.utc).isoformat()
    encryption = {} if os.environ.get("ICEBERG_OPS_LOCAL_MODE") == "1" else {"ServerSideEncryption": "AES256"}
    s3.put_object(Bucket=result_url.netloc, Key=result_url.path.lstrip("/"),
        Body=json.dumps(result, default=str).encode(), ContentType="application/json", **encryption)
    spark.stop()
    if failed:
        raise RuntimeError("One or more tables failed. Inspect the saved per-table results.")


if __name__ == "__main__":
    main()
