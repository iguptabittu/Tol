'use strict';
const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const activeStates = new Set(['SUBMITTING','SUBMITTED','PENDING','SCHEDULED','QUEUED','RUNNING','CANCELLING']);
const state = {workspaces: [], workspace: '', data: null, page: 'home', selected: new Map(), plan: null, editingSchedule: null, newConnection: false, refreshing: false};
const connectionFields = [
  ['name','Workspace name','Example: Development · Mumbai','text',true],
  ['aws_profile','AWS CLI profile','iceberg-ops','text'],
  ['account_id','AWS account ID','12-digit account ID','text'],
  ['region','AWS region','ap-south-1','text',true],
  ['application_id','EMR Serverless application ID','From stack outputs','text'],
  ['execution_role_arn','Execution IAM role ARN','arn:aws:iam::…:role/…','text'],
  ['bucket','Operations S3 bucket','From stack outputs','text'],
  ['prefix','Operations S3 prefix','iceberg-ops','text',true],
  ['warehouse','Iceberg warehouse URI','s3://data-bucket/warehouse/','text'],
  ['databases','Glue databases (comma-separated)','analytics, events','text'],
  ['assume_role_arn','Assume role ARN (optional)','For cross-account access','text'],
  ['execution_timeout_minutes','Job timeout (minutes)','60','number',true]
];
const policies = [
  ['target_mb','Target file size (MB)',512,64,2048,1],
  ['small_mb','Small-file threshold (MB)',128,1,1024,1],
  ['min_files','Minimum small files',5,2,10000,1],
  ['max_group_gb','Maximum rewrite group (GB)',8,.25,100,.25],
  ['parallel_groups','Concurrent rewrite groups',2,1,8,1],
  ['cooldown_hours','Cooldown (hours)',72,0,8760,1],
  ['max_inventory_age_minutes','Maximum inventory age (minutes)',60,5,1440,1]
];
const defaultPolicy = () => Object.fromEntries(policies.map(([key,,value]) => [key,value]));
const fmt = value => value ? new Date(value).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'}) : '—';
const size = bytes => bytes >= 1073741824 ? (bytes/1073741824).toFixed(2)+' GB' : ((bytes||0)/1048576).toFixed(1)+' MB';
const selected = () => state.selected.get(state.workspace) || new Set();
const workspace = () => state.workspaces.find(w=>w.id===state.workspace);
const localMode = () => workspace()?.backend==='local';
const metrics = rows => rows.map(([key,value])=>`<div class="metric"><span>${esc(key)}</span><b>${esc(value)}</b></div>`).join('');

function toast(message, bad=false) { $('toast').textContent=message; $('toast').classList.toggle('bad-toast',bad); $('toast').classList.add('visible'); clearTimeout(toast.timer); toast.timer=setTimeout(()=>$('toast').classList.remove('visible'),5500); }
async function api(path, options={}) {
  const response=await fetch(path,{...options,headers:{'Content-Type':'application/json','X-Ops-Request':'1',...(options.headers||{})}});
  if(response.status===204) return null;
  let result; try { result=await response.json(); } catch { throw Error('The backend returned an unreadable response.'); }
  if(!response.ok) throw Error(Array.isArray(result.detail)?result.detail.map(e=>e.loc.join('.')+': '+e.msg).join('; '):result.detail||'Request failed');
  return result;
}
const base = () => '/api/workspaces/'+encodeURIComponent(state.workspace);
async function action(button, fn) { const was=button.disabled; button.disabled=true; try { await fn(); } catch(error) { toast(error.message,true); } finally { button.disabled=was; } }

function nav(page) {
  state.page=page;
  for(const section of document.querySelectorAll('.section')) section.classList.toggle('active',section.id===page);
  for(const button of document.querySelectorAll('[data-page]')) button.classList.toggle('active',button.dataset.page===page);
  const titles={home:['Maintenance overview','Understand your file layout. Review changes. Run with confidence.'],schedules:['Recurring schedules','Keep maintenance predictable, with a policy saved for each schedule.'],runs:['Runs & history','Follow real Spark work and inspect the measured outcome.'],setup:['Connections & policy','Connect your account and define how maintenance should behave.']};
  $('pageHeading').textContent=titles[page][0]; $('pageHint').textContent=titles[page][1];
  if(page==='setup') renderSetup();
  window.scrollTo({top:0});
}
function contextRender() {
  const ws=workspace();
  $('computeBadge').textContent=localMode()?'LOCAL SPARK / S3':'EMR SERVERLESS';
  $('executionLabel').textContent=localMode()?'Docker Spark execution':'EMR Serverless execution';
  $('workspaceSelect').innerHTML=state.workspaces.length?state.workspaces.map(w=>`<option value="${esc(w.id)}" ${w.id===state.workspace?'selected':''}>${esc(w.name)} · ${esc(w.region)}</option>`).join(''):'<option value="">No workspace configured</option>';
  $('contextMeta').textContent=ws?`${localMode()?'Local Docker':ws.account_id||'Account not set'} · ${localMode()?'REST catalog':ws.region} · ${ws.databases.join(', ')||'No databases selected'}`:'Connect an AWS account to get started.';
  $('connectionBadge').textContent=ws?.connection?.ok?(localMode()?'LOCAL DOCKER CONNECTED':'AWS CONNECTION VERIFIED'):ws?(localMode()?'DOCKER SETUP REQUIRED':'AWS SETUP REQUIRED'):'CHOOSE A CONNECTION';
  $('connectionBadge').className='pill '+(ws?.connection?.ok?'green':'neutral');
  $('exportHistory').href=ws?base()+'/history.csv':'#'; $('exportSchedules').href=ws?base()+'/schedules.json':'#';
}
async function refresh(all=false) {
  if(state.refreshing) return;
  state.refreshing=true;
  try {
    if(all) {
      const info=await api('/api/system'); state.workspaces=info.workspaces;
      $('appVersion').textContent='v'+info.version; $('backendState').textContent='Backend connected';
      if(!state.workspaces.some(w=>w.id===state.workspace)) state.workspace=state.workspaces[0]?.id||'';
    }
    if(state.workspace) {
      const id=state.workspace, data=await api('/api/workspaces/'+encodeURIComponent(id));
      if(id!==state.workspace) return;
      state.data=data; state.workspaces=state.workspaces.map(w=>w.id===id?data.workspace:w);
      if(!state.selected.has(id)&&data.tables.length) state.selected.set(id,new Set(data.tables.filter(t=>t.eligible).map(t=>t.name)));
    } else state.data=null;
    const health=await api('/api/health');
    $('backendState').textContent=health.worker?'Backend running':'Backend connected · scheduler stopped';
    $('backendDot').classList.toggle('offline',!health.worker);
    $('syncState').textContent='Synced '+new Date().toLocaleTimeString();
    contextRender(); renderHome(); renderSchedules(); renderRuns();
  } catch(error) { $('backendState').textContent='Backend unavailable'; $('backendDot').classList.add('offline'); $('syncState').textContent=error.message; }
  finally {state.refreshing=false;}
}
function renderHome() {
  const data=state.data, ws=workspace(); $('welcome').classList.toggle('hide',!!ws); $('dashboard').classList.toggle('hide',!ws); if(!ws||!data)return;
  document.querySelector('#runs .headingrow p').textContent=localMode()?'Local Spark job state, measured file counts, and driver logs.':'AWS job state, measured file counts, and resource usage.';
  document.querySelector('#dashboard .headingrow p').textContent=localMode()?'Recommendations come from real local Iceberg metadata.':'Recommendations come from your latest AWS metadata scan.';
  document.querySelector('#dashboard .side-summary .notice').textContent=localMode()?'Jobs run in Docker on this Mac. No AWS account or AWS charges.':'Metadata scans and maintenance run on AWS and incur AWS charges.';
  document.querySelector('#schedules > .notice').textContent=localMode()?'Keep this Mac awake, Docker running, and the backend running for scheduled jobs. Missed occurrences are skipped.':'Keep this Mac awake and the backend running for scheduled submissions. AWS continues accepted jobs if the browser closes. Missed occurrences are skipped.';
  const busy=data.runs.some(r=>activeStates.has(r.state));
  $('scanMetadata').disabled=busy; $('scanMetadata').textContent=busy?'Job in progress':'↻ Refresh metadata';
  $('kAttention').textContent=data.tables.filter(t=>t.eligible).length;
  $('kSmall').textContent=data.tables.reduce((n,t)=>n+(t.small_files||0),0).toLocaleString();
  $('kSchedules').textContent=data.schedules.filter(s=>s.enabled).length;
  $('kRun').previousElementSibling.textContent=localMode()?'Latest Spark job':'Latest AWS job';
  $('kRun').textContent=data.runs[0]?.state.replaceAll('_',' ')||'No jobs yet'; $('kRunHint').textContent=data.runs[0]?data.runs[0].kind+' · '+fmt(data.runs[0].created_at):'Refresh metadata to begin';
  $('inventoryNotice').classList.toggle('hide',!!data.tables.length);
  $('inventoryNotice').textContent='No metadata has been collected. Connect Docker or AWS, then refresh metadata to discover your Iceberg tables.';
  const needle=$('tableSearch').value.toLowerCase();
  $('tableCount').textContent=data.tables.length+' TABLES';
  $('tableRows').innerHTML=data.tables.filter(t=>t.name.toLowerCase().includes(needle)).map(t=>`<tr><td><input type="checkbox" data-table="${esc(t.name)}" ${selected().has(t.name)?'checked':''} ${!t.eligible?'disabled':''} aria-label="Select ${esc(t.name)}"></td><td><div class="table-title">${esc(t.name)}</div><div class="row-help">${(t.file_count||0).toLocaleString()} data files · ${t.partitions||0} partitions</div><details class="table-details"><summary>Details</summary><div class="small muted">${esc([...t.reasons,...t.blocked].join(' · '))}<br>Scanned: ${esc(fmt(t.scanned_at))}<br>Snapshot: ${esc(t.snapshot_id||'—')}</div></details></td><td>${(t.small_files||0).toLocaleString()}</td><td>${size(t.bytes)}</td><td><span class="pill ${t.eligible?'green':'neutral'}">${t.eligible?'Recommended':'Skipped'}</span></td></tr>`).join('')||'<tr><td colspan="5" class="empty">No tables to display.</td></tr>';
  $('tableRows').querySelectorAll('[data-table]').forEach(input=>input.onchange=()=>{const values=new Set(selected()); input.checked?values.add(input.dataset.table):values.delete(input.dataset.table);state.selected.set(state.workspace,values);renderSummary();});
  renderSummary();
}
function renderSummary() {
  const tables=(state.data?.tables||[]).filter(t=>selected().has(t.name)&&t.eligible), ws=workspace();
  $('planSummary').innerHTML=metrics([['Eligible tables selected',tables.length],['Table data observed',size(tables.reduce((n,t)=>n+(t.bytes||0),0))],['Small files observed',tables.reduce((n,t)=>n+(t.small_files||0),0).toLocaleString()],['Target file size',(ws?.policy.target_mb||512)+' MB'],['Maximum rewrite group',(ws?.policy.max_group_gb||8)+' GB']]);
  $('reviewPlan').disabled=!tables.length||state.data?.runs.some(r=>activeStates.has(r.state)); $('scheduleSelection').disabled=!selected().size;
}
function renderSchedules() {
  const list=state.data?.schedules||[];
  $('newSchedule').disabled=!workspace();
  $('scheduleList').innerHTML=list.map(s=>`<article class="card schedule-entry"><div><div class="buttonrow"><h3>${esc(s.name)}</h3><span class="pill ${s.enabled?'green':'neutral'}">${s.enabled?'Enabled':'Paused'}</span></div><p class="schedule-meta"><code>${esc(s.expression)}</code> · ${esc(s.timezone)} · ${s.scope==='auto'?'Automatic eligibility':s.tables.length+' chosen tables'}</p><p class="muted small">${s.enabled?'Next: '+esc(fmt(s.next_at)):'Not currently active'}</p>${s.last_error?`<p class="error-text small">${esc(s.last_error)}</p>`:''}</div><div class="buttonrow"><button class="btn tiny" data-edit-schedule="${s.id}">Edit</button><button class="btn tiny danger" data-delete-schedule="${s.id}">Delete</button></div></article>`).join('')||'<div class="card empty">No schedules yet. Create one after connecting a workspace.</div>';
  $('scheduleList').querySelectorAll('[data-edit-schedule]').forEach(b=>b.onclick=()=>openSchedule(list.find(s=>s.id===b.dataset.editSchedule)));
  $('scheduleList').querySelectorAll('[data-delete-schedule]').forEach(b=>b.onclick=()=>action(b,async()=>{if(!confirm('Delete this schedule? Already submitted jobs will continue.'))return;await api(base()+'/schedules/'+b.dataset.deleteSchedule,{method:'DELETE'});await refresh();toast('Schedule deleted.');}));
}
function renderRuns() {
  const data=state.data;
  $('runList').innerHTML=(data?.runs||[]).map(r=>{
    const ws=workspace(), usage=r.usage;
    const awsURL=r.job_id&&!localMode()?`https://${ws.region}.console.aws.amazon.com/emr/home?region=${ws.region}#/serverless/applications/${ws.application_id}/jobruns/${r.job_id}`:null;
    const results=(r.result?.tables||[]).map(t=>`<div class="metric"><span>${esc(t.name)}</span><b>${t.error?'Needs review':esc(t.file_count+' files · '+size(t.bytes))}</b></div>`).join('');
    return `<article class="card run-card"><div class="headingrow"><div><div class="eyebrow">${r.kind==='inventory'?'READ-ONLY METADATA SCAN':'TABLE COMPACTION'}</div><h3 class="spaced-small">${r.kind==='inventory'?'Inventory refresh':'Maintenance job'}</h3><div class="muted small">${esc(fmt(r.created_at))}</div></div><span class="pill ${r.state==='SUCCESS'?'green':r.state==='FAILED'?'red':activeStates.has(r.state)?'amber':'neutral'}">${esc(r.state)}</span></div><p class="run-id">${esc(r.id)}</p><p class="small muted">${esc(r.details||'')}${r.cancel_requested?' · Cancellation requested':''}</p>${r.error?`<div class="notice bad">${esc(r.error)}</div>`:''}${r.result_error?`<div class="notice">Measured results unavailable: ${esc(r.result_error)}</div>`:''}${usage?`<div class="tags spaced-small"><span class="pill neutral">${Number(usage.vCPUHour||0).toFixed(3)} vCPU hours</span><span class="pill neutral">${Number(usage.memoryGBHour||0).toFixed(3)} GB hours</span>${r.duration_seconds?`<span class="pill neutral">${r.duration_seconds}s elapsed</span>`:''}</div>`:''}${results?`<details><summary>Measured table results</summary>${results}${r.result.actions.filter(a=>a.error).map(a=>`<p class="error-text small">${esc(a.name+': '+a.error)}</p>`).join('')}</details>`:''}<div class="buttonrow spaced-small">${awsURL?`<a class="btn tiny" href="${esc(awsURL)}" target="_blank" rel="noopener">Open in AWS ↗</a>`:''}${r.job_id?`<button class="btn tiny" data-logs="${r.id}">Driver logs</button>`:''}${activeStates.has(r.state)?`<button class="btn tiny danger" data-cancel="${r.id}" ${r.cancel_requested?'disabled':''}>Cancel job</button>`:''}</div></article>`;
  }).join('')||'<div class="card empty">No Spark jobs submitted yet. Refresh metadata from Overview to start.</div>';
  $('eventLog').innerHTML=(data?.events||[]).map(e=>`<div><span class="subtle">${esc(fmt(e.time))}</span><br>${esc(e.message)}</div>`).join('')||'No events yet.';
  $('runList').querySelectorAll('[data-cancel]').forEach(b=>b.onclick=()=>action(b,async()=>{if(!confirm('Cancel this Spark job? Completed Iceberg commits remain in place.'))return;await api(base()+'/runs/'+b.dataset.cancel+'/cancel',{method:'POST'});await refresh();}));
  $('runList').querySelectorAll('[data-logs]').forEach(b=>b.onclick=()=>action(b,async()=>{$('driverLogs').textContent='Loading driver logs from S3…';$('logsDialog').showModal();const result=await api(base()+'/runs/'+b.dataset.logs+'/logs');$('driverLogs').textContent=result.logs;}));
}
function policyForm(container, values, prefix) {
  $(container).innerHTML=policies.map(([key,label,def,min,max,step])=>`<div class="field"><label for="${prefix+key}">${esc(label)}</label><input type="number" id="${prefix+key}" min="${min}" max="${max}" step="${step}" value="${values?.[key]??def}" required></div>`).join('');
}
function readPolicy(prefix) {return Object.fromEntries(policies.map(([key])=>[key,Number($(prefix+key).value)]));}
function renderSetup() {
  const ws=state.newConnection?null:workspace();
  $('ws_backend').value=ws?.backend||'aws';
  $('setupHeading').textContent=ws?'Workspace connection & policy':'Connect your AWS workspace';
  const defaults={name:'',region:'ap-south-1',prefix:'iceberg-ops',execution_timeout_minutes:60};
  $('connectionFields').innerHTML=connectionFields.map(([key,label,placeholder,type,required])=>`<div class="field"><label for="ws_${key}">${esc(label)}</label><input id="ws_${key}" type="${type}" value="${esc(Array.isArray(ws?.[key])?ws[key].join(', '):ws?.[key]??defaults[key]??'')}" placeholder="${esc(placeholder)}" ${required?'required':''} ${type==='number'?'min="5" max="720"':''}></div>`).join('');
  policyForm('policyFields',ws?.policy,'ws_policy_');
  toggleBackendFields();
  $('testConnection').disabled=!ws; $('connectionResult').textContent=ws?.connection?.error||'';
}
function openSchedule(existing=null, chosen=false) {
  if(!workspace()){toast('Create a workspace first.',true);nav('setup');return;}
  state.editingSchedule=existing?structuredClone(existing):null;
  $('scheduleTitle').textContent=existing?'Edit schedule':'New schedule';
  $('scheduleName').value=existing?.name||'Nightly maintenance';
  $('schedulePreset').value=existing?'custom':'daily'; $('scheduleTime').value='02:00';
  $('scheduleZone').value=existing?.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone||'Asia/Kolkata';
  $('scheduleCron').value=existing?.expression||'0 2 * * *';
  $('scheduleScope').value=existing?.scope||(chosen?'selected':'auto');
  const chosenTables=new Set(existing?.tables||[...selected()]);
  const names=new Set([...(state.data?.tables||[]).map(t=>t.name),...chosenTables]);
  $('scheduleTables').innerHTML=[...names].sort().map(name=>`<option value="${esc(name)}" ${chosenTables.has(name)?'selected':''}>${esc(name)}</option>`).join('');
  $('scheduleApproval').nextElementSibling.textContent=localMode()?'I approve recurring local metadata scans and Iceberg rewrites within this scope.':'I approve recurring AWS metadata scans and maintenance within this scope.';
  $('scheduleEnabled').checked=existing?.enabled||false; $('scheduleApproval').checked=existing?.approved||false;
  policyForm('schedulePolicyFields',existing?.policy||workspace().policy,'sch_policy_');
  $('scheduleDialog').showModal(); updateCron();
}
let cronSequence=0;
async function updateCron() {
  const preset=$('schedulePreset').value, [hour,minute]=($('scheduleTime').value||'02:00').split(':').map(Number);
  const stamp=`${minute} ${hour}`;
  if(preset!=='custom') $('scheduleCron').value=preset==='hourly'?'0 * * * *':preset==='sixhours'?'0 */6 * * *':preset==='weekdays'?`${stamp} * * 1-5`:preset==='weekly'?`${stamp} * * ${$('scheduleDay').value}`:`${stamp} * * *`;
  $('scheduleTimeWrap').classList.toggle('hide',['hourly','sixhours','custom'].includes(preset)); $('scheduleDayWrap').classList.toggle('hide',preset!=='weekly');
  $('scheduleTablesWrap').classList.toggle('hide',$('scheduleScope').value!=='selected');
  const sequence=++cronSequence; $('saveSchedule').disabled=true;
  try {const result=await api('/api/cron?'+new URLSearchParams({expression:$('scheduleCron').value,timezone:$('scheduleZone').value}));if(sequence!==cronSequence)return;$('schedulePreview').innerHTML=result.occurrences.map(d=>esc(new Date(d).toLocaleString(undefined,{timeZone:$('scheduleZone').value,dateStyle:'full',timeStyle:'short'}))).join('<br>');$('saveSchedule').disabled=false;}
  catch(error){if(sequence===cronSequence)$('schedulePreview').textContent=error.message;}
}

function toggleBackendFields(){const isLocal=$('ws_backend').value==='local';$('localSetupHelp').classList.toggle('hide',!isLocal);document.querySelectorAll('.aws-help').forEach(el=>el.classList.toggle('hide',isLocal));for(const [key] of connectionFields)$('ws_'+key).closest('.field').classList.toggle('hide',isLocal&&!['name','databases','execution_timeout_minutes'].includes(key));}
$('ws_backend').onchange=toggleBackendFields;
$('setupLocal').onclick=()=>action($('setupLocal'),async()=>{const result=await api('/api/local/workspace',{method:'POST'});state.workspace=result.id;await refresh(true);toast('Local Docker lake connected. Refresh metadata to inspect its tables.');});

for(const button of document.querySelectorAll('[data-page]'))button.onclick=()=>{if(button.dataset.page==='setup')state.newConnection=false;nav(button.dataset.page);};
for(const button of document.querySelectorAll('[data-close]'))button.onclick=()=>$(button.dataset.close).close();
for(const dialog of document.querySelectorAll('dialog'))dialog.addEventListener('keydown',event=>{
  if(event.key!=='Tab')return;
  const focusable=[...dialog.querySelectorAll('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),summary')].filter(el=>el.getClientRects().length&&!el.closest('details:not([open]) :not(summary)'));
  const first=focusable[0],last=focusable.at(-1);
  if(!first){event.preventDefault();return;}
  if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
  else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
});
$('addWorkspace').onclick=$('setupCTA').onclick=()=>{state.newConnection=true;nav('setup');};
$('workspaceSelect').onchange=async e=>{state.workspace=e.target.value;state.data=null;state.newConnection=false;await refresh();if(state.page==='setup')renderSetup();};
$('tableSearch').oninput=renderHome;
$('selectRecommended').onclick=()=>{state.selected.set(state.workspace,new Set(state.data.tables.filter(t=>t.eligible).map(t=>t.name)));renderHome();};
$('clearSelection').onclick=()=>{state.selected.set(state.workspace,new Set());renderHome();};
$('scanMetadata').onclick=()=>action($('scanMetadata'),async()=>{await api(base()+'/scan',{method:'POST'});nav('runs');await refresh();toast('Metadata scan queued for the selected Spark backend.');});
$('reviewPlan').onclick=()=>action($('reviewPlan'),async()=>{state.plan=await api(base()+'/plans',{method:'POST',body:JSON.stringify({tables:[...selected()]})});const p=state.plan,ws=workspace();$('planDetails').innerHTML=`<div class="notice">${esc(ws.name)} · ${esc(localMode()?'Local Docker':ws.account_id)} · ${esc(ws.region)}</div>${metrics([['Tables',p.tables.length],['Table data observed',size(p.input_bytes)],['Small files observed',p.small_files.toLocaleString()],['Rewrite group limit',p.policy.max_group_gb+' GB'],['Valid until',fmt(p.expires_at)]])}<div class="plain spaced">${p.tables.map(t=>`<p><b>${esc(t.name)}</b><br><span class="muted small">Snapshot ${esc(t.snapshot_id)}</span></p>`).join('')}</div><p class="muted small">Runs table-level binpack compaction. The runtime depends on the files Iceberg selects. Snapshot expiration and orphan-file deletion are not part of this plan.</p>${p.skipped.length?`<div class="notice">${p.skipped.length} tables skipped under this policy.</div>`:''}`;$('planSQL').textContent=p.sql;$('planApproval').checked=false;$('submitPlan').textContent=localMode()?'Run local Spark job →':'Submit AWS job →';$('planApproval').nextElementSibling.textContent=localMode()?'I approve rewriting these local Iceberg tables.':'I approve this AWS job for the selected account and tables.';$('submitPlan').disabled=true;$('planDialog').showModal();});
$('planApproval').onchange=()=>{$('submitPlan').disabled=!$('planApproval').checked;};
$('submitPlan').onclick=()=>action($('submitPlan'),async()=>{await api(base()+'/runs',{method:'POST',body:JSON.stringify({plan_id:state.plan.id,approved:$('planApproval').checked})});$('planDialog').close();nav('runs');await refresh();toast('Approved maintenance job queued for Spark.');});
$('copySQL').onclick=()=>action($('copySQL'),async()=>{await navigator.clipboard.writeText($('planSQL').textContent);toast('SQL copied.');});
$('newSchedule').onclick=()=>openSchedule(); $('scheduleSelection').onclick=()=>openSchedule(null,true);
for(const id of ['schedulePreset','scheduleTime','scheduleDay','scheduleZone','scheduleScope'])$(id).onchange=updateCron;
$('scheduleCron').oninput=()=>{$('schedulePreset').value='custom';clearTimeout(updateCron.timer);updateCron.timer=setTimeout(updateCron,200);};
$('scheduleForm').onsubmit=e=>{e.preventDefault();action($('saveSchedule'),async()=>{const body={name:$('scheduleName').value,expression:$('scheduleCron').value,timezone:$('scheduleZone').value,scope:$('scheduleScope').value,tables:[...$('scheduleTables').selectedOptions].map(o=>o.value),policy:readPolicy('sch_policy_'),enabled:$('scheduleEnabled').checked,approved:$('scheduleApproval').checked};const editing=state.editingSchedule;await api(base()+'/schedules'+(editing?'/'+editing.id:''),{method:editing?'PUT':'POST',body:JSON.stringify(body)});$('scheduleDialog').close();await refresh();toast('Schedule saved in the backend.');});};
$('workspaceForm').onsubmit=e=>{e.preventDefault();action($('saveWorkspace'),async()=>{const body=Object.fromEntries(connectionFields.map(([key,,,type])=>[key,type==='number'?Number($('ws_'+key).value):$('ws_'+key).value.trim()]));body.backend=$('ws_backend').value;body.databases=body.databases.split(',').map(s=>s.trim()).filter(Boolean);body.policy=readPolicy('ws_policy_');const editing=!state.newConnection&&workspace();const result=await api('/api/workspaces'+(editing?'/'+editing.id:''),{method:editing?'PUT':'POST',body:JSON.stringify(body)});state.workspace=result.id;state.newConnection=false;await refresh(true);renderSetup();toast('Workspace saved. Test the connection next.');});};
$('testConnection').onclick=()=>action($('testConnection'),async()=>{$('connectionResult').textContent='Checking the selected compute, catalog, and storage connection…';const result=await api(base()+'/check',{method:'POST'});$('connectionResult').textContent=result.ok?`Connected: ${result.account_id} · ${result.release} · ${result.application_state}`:result.error;$('connectionResult').classList.toggle('error-text',!result.ok);await refresh();});
$('stackOutputs').onchange=async e=>{try{const file=e.target.files[0];if(!file)return;const parsed=JSON.parse(await file.text());const outputs=parsed.Stacks?.[0]?.Outputs||parsed.Outputs||parsed;const values=Array.isArray(outputs)?Object.fromEntries(outputs.map(o=>[o.OutputKey,o.OutputValue])):outputs;for(const [key,field] of Object.entries({AccountId:'account_id',Region:'region',ApplicationId:'application_id',ExecutionRoleArn:'execution_role_arn',OperationsBucket:'bucket',WarehouseUri:'warehouse',GlueDatabase:'databases'}))if(values[key])$('ws_'+field).value=values[key];toast('Stack outputs imported. Review and save the connection.');}catch(error){toast('Could not read stack outputs: '+error.message,true);}};
refresh(true).then(()=>{if(!state.workspace)renderSetup();});
setInterval(()=>{if(!document.hidden&&!document.querySelector('dialog[open]'))refresh();},5000);
