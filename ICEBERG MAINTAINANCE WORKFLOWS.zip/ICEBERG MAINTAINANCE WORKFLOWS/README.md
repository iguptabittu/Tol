# Iceberg Ops

A local web app for live AWS Glue / Apache Iceberg maintenance using EMR
Serverless. Replaces the standalone HTML simulator with a FastAPI backend,
SQLite persistence, an unattended local scheduler, real Spark jobs, and run
reconciliation after restart.

**No AWS account?** Use the [local Docker lab](docs/LOCAL_DOCKER.md): real Spark,
Iceberg tables, S3-compatible storage, compaction, and schedules on this Mac.

```sh
docker compose -f compose.local.yaml up -d --build
```

Then start the app below and choose **Open local Docker lab**.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run.py
```

Open **http://127.0.0.1:8765**. Follow [the setup guide](docs/SETUP.md) to sign in to
AWS and provision infrastructure. The application starts empty and makes no
AWS calls until a connection test or job submission is requested.

On this Mac, you can also double-click **Start Iceberg Ops.command**. For local
Docker mode, start the Docker services first; the app's local connection needs no
AWS profile. See [the local guide](docs/LOCAL_DOCKER.md) for stop/resume commands.

Persistent records live in `data/` (ignored by Git). The app uses the AWS SDK's
credential chain and never asks for or saves access keys. Keep the backend running
and this Mac awake for scheduled submissions. Accepted AWS jobs continue when
the browser is closed.

Tests: `python3 -m unittest discover -s tests -v` (install `requirements-dev.txt`).

The implementation is ready for AWS connection; live cloud acceptance requires
your AWS account, deployed stack, and real Iceberg tables. See the guide for
scope, permissions, and recovery behavior.
