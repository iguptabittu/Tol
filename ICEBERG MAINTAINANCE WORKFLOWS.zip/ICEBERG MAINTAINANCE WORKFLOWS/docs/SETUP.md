# Run Iceberg Ops on this Mac

This application submits real EMR Serverless Spark jobs. It starts with no synthetic
workspaces or table data. The local database, scheduler, and UI work without AWS.
For real scans and rewrites without an AWS account, use [the Docker lab](LOCAL_DOCKER.md).

## 1. Start the app

From the project directory, use Python 3.11 or newer:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run.py
```

Open http://127.0.0.1:8765. The server listens on loopback only. Keep one server
process per database. Data is saved to `data/iceberg-ops.sqlite3`. To change the
port or database: `python run.py --port 8766 --db /absolute/path/ops.sqlite3`.

## 2. Sign in to AWS

Install AWS CLI v2 and use your organization's IAM Identity Center (SSO) setup:

```sh
aws configure sso --profile iceberg-ops
aws sso login --profile iceberg-ops
aws sts get-caller-identity --profile iceberg-ops
```

Use the returned account ID in the setup commands and connection form. Do not
paste keys into the app. The SDK also supports its default credential provider
chain when the AWS profile field is blank. SSO sessions expire; sign in again
when the app reports an expired login. For cross-account access, configure a
permitted assume-role ARN and use the target account ID.

## 3. Review infrastructure

The supplied `infrastructure/cloudformation.json` creates:

- An EMR Serverless Spark application using the configurable EMR 7.12.0 release.
- Maximum application capacity of 16 vCPU, 64 GB memory, and 200 GB disk.
- Auto-start on submission, auto-stop after five idle minutes, no prewarmed workers.
- A versioned, encrypted operations S3 bucket with public access blocked.
- An execution role restricted to that application, one Glue database, and the
  configured data-bucket prefix.
- Optionally a dedicated data bucket and a Glue database if you do not have them.

Buckets and the Glue database are retained on stack deletion. Existing data must
be in the selected warehouse prefix for the execution role to access it. Expand
permissions intentionally if your tables span other prefixes or buckets. This
template targets commercial AWS regions and the AWS Glue catalog.

Create a change set using your real account ID; this does not execute it:

```sh
.venv/bin/python tools/provision.py --profile iceberg-ops --account-id YOUR_ACCOUNT_ID --region ap-south-1
```

For existing tables:

```sh
.venv/bin/python tools/provision.py --profile iceberg-ops --account-id YOUR_ACCOUNT_ID --region ap-south-1 --data-bucket YOUR_DATA_BUCKET --warehouse-prefix warehouse/ --database YOUR_GLUE_DATABASE --existing-database
```

The tool prints proposed changes and an exact `execute-change-set` command. Review
that change set in CloudFormation before running the printed command. When the
stack finishes, export its connection settings:

```sh
aws cloudformation describe-stacks --stack-name iceberg-ops --profile iceberg-ops --region ap-south-1 --output json > /tmp/iceberg-ops-outputs.json
```

In Connections & policy, import that JSON, select your AWS profile, name the
workspace, save, and test the connection. Import only fills the form; it does not
submit a job. New buckets/databases are empty until you create or register actual
Iceberg tables. The app discovers existing Glue tables with Iceberg metadata.

The local operator profile needs STS GetCallerIdentity, Glue GetDatabase/GetTables,
S3 HeadBucket/ListBucket/GetObject/PutObject on the operations bucket and prefix,
EMR Serverless GetApplication/StartJobRun/GetJobRun/CancelJobRun, and IAM PassRole
for the execution role with iam:PassedToService=emr-serverless.amazonaws.com.
Provisioning additionally needs permissions to manage the declared resources.
Ask your AWS administrator to scope these to the stack's output ARNs; the app
does not create or widen permissions for your signed-in identity.

For KMS-encrypted existing data, pass `--kms-key YOUR_KEY_ARN` and ensure the key
policy grants the role access. Lake Formation governed tables need appropriate
Lake Formation grants and any required EMR application configuration. These grants
are account-specific and are not inferred by the template.

## 4. First metadata scan and rewrite

1. In Overview, choose Refresh metadata. This submits a read-only Spark job and
   incurs AWS compute charges. The driver inspects live Iceberg file manifests,
   including current snapshot, file count, bytes, small files, and partition count.
2. Follow the inventory job in Runs & history. Results are written to S3 and then
   imported into SQLite by the backend. Errors and unavailable results are shown.
3. Select eligible development tables, review the generated SQL, check the
   approval box, then submit the job. Plans expire after 15 minutes.
4. Each selected table is compacted with Iceberg's `rewrite_data_files` procedure.
   The group ceiling and parallel-group settings are real Iceberg options.
   The job checks the snapshot before each rewrite; a changed snapshot fails that
   table and requires a new scan/review. Other applications may still commit
   concurrently; Iceberg's own optimistic concurrency checks remain in force.
5. Review measured file counts, per-table errors, Spark driver logs, and EMR
   resource usage. Resource usage is not a dollar-price estimate.

The first version handles table-level binpack compaction on EMR Serverless.
It does not implement partition-specific rewrites, EMR cluster steps, snapshot
expiration, orphan-file deletion, or a hosted multiuser service.

## 5. Recurring schedules

Schedules store their own table scope and maintenance policy. Editing a name
does not take table choices or policy from Overview. Enable a schedule and approve
its scope to authorize future scans and rewrites. Every occurrence runs a fresh
inventory job before planning maintenance; there is at most one active app-managed
job per workspace. If no tables are eligible, maintenance is skipped.

Keep the Mac awake and the backend running. Browser closure has no effect on the
backend or AWS jobs. If the backend restarts, accepted AWS jobs are reconciled by
their saved IDs. Missed schedule times older than one minute and occurrences
blocked by an active workspace job are skipped, with an activity entry. The app
does not claim to schedule work while this Mac is asleep or powered off.

Cron supports numeric five-field expressions with lists, ranges, steps, and IANA
timezones. Sunday is 0 or 7. Restricted day-of-month and day-of-week fields use OR;
fields beginning with * retain wildcard semantics. Spring-forward nonexistent
times are skipped; repeated fall-back times can run twice. Leap-day schedules
are valid; the preview allows up to eight years per occurrence.

For an always-on deployment, move the backend and database to an always-on host;
do not expose this loopback application directly to a network. Add authentication,
TLS, and shared coordination before supporting multiple operators or replicas.

## Operations and recovery

- Back up SQLite using its online backup API or stop the server before copying
  the database. Do not copy only the .sqlite3 file while WAL writes are active.
- Cancellation asks EMR to stop remaining work; committed Iceberg changes remain.
  If the result is incomplete, inventory is invalidated and must be rescanned.
- Submissions use persisted AWS client tokens. A lost HTTP response retries the
  same token, and an already submitted plan returns the original run.
- Do not manually remove run rows while jobs are active. Changing AWS targets
  pauses stored schedules and invalidates old inventory/plans.
- Scripts, manifests, results, and EMR driver logs live under `iceberg-ops/` in
  the operations bucket. They contain table metadata and should remain private.
- Glue discovery accepts standard database/table identifiers composed of letters,
  numbers, and underscores. Other identifiers are reported explicitly.
- App locks coordinate this database only; a second installation or external
  maintenance system needs its own shared coordination and operational controls.

## Validation

```sh
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m unittest discover -s tests -v
node --check web/app.js
```

The automated suite uses isolated SQLite databases and an AWS test adapter. It
does not incur AWS charges. A real AWS scan/rewrite is a separate acceptance test
after sign-in and infrastructure deployment.

Official references: [EMR Serverless with Iceberg](https://docs.aws.amazon.com/emr/latest/EMR-Serverless-UserGuide/using-iceberg.html),
[Iceberg rewrite procedures](https://iceberg.apache.org/docs/latest/spark-procedures/),
[CloudFormation EMR Serverless application](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-emrserverless-application.html).
