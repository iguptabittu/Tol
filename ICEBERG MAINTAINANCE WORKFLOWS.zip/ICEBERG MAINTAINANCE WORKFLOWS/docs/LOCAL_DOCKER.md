# Real local Iceberg lab — no AWS account

The app can run actual Spark / Iceberg maintenance on this Mac using Docker.
The stack contains Apache Spark 3.5.5, Apache Iceberg 1.9.0, a durable Iceberg
REST catalog, and RustFS for S3-compatible object storage. This follows the
[Apache Iceberg quickstart architecture](https://iceberg.apache.org/spark-quickstart/).

It runs real Parquet writes and Iceberg metadata commits, not simulated file
counts. AWS IAM, Glue, EMR job scheduling, billing, and managed-service behavior
are not emulated. The existing AWS adapter remains available for later.

## Start

1. Start Docker Desktop. Allow roughly 6 GB of Docker memory and several GB of
   free disk for the initial images/build and data.
2. From this project directory:

```sh
docker compose -f compose.local.yaml up -d --build
python3 run.py
```

On first boot, image downloads and Spark initialization take a few minutes.
The Spark worker creates two real tables (`analytics.events`, `analytics.orders`),
each with 12,000 rows and deliberately small files. Existing tables are retained
on subsequent starts; initialization never drops or overwrites them.

3. Open http://127.0.0.1:8765 and choose **Open local Docker lab**. If tables are
   still being prepared, wait briefly and retry.
4. Choose **Refresh metadata**, wait for the local Spark scan to complete, then
   select tables, review the generated SQL, approve, and run compaction.
5. Inspect the measured file counts and driver logs in Runs & history. Scheduling
   uses the same durable backend as AWS mode. Keep Docker, the backend, and this
   Mac running for scheduled local jobs.

The first rewrite should reduce the deliberately small-file backlog. Later plans
may have no eligible work; that reflects the real post-compaction table layout.
The normal cooldown policy applies. This setup does not automatically recreate
fragmentation or invent new recommendations after a successful rewrite.

## Local services

- App: http://127.0.0.1:8765
- S3-compatible API: http://127.0.0.1:9000
- Object-storage console: http://127.0.0.1:9001
- Iceberg REST catalog: http://127.0.0.1:8181
- Local Spark runner: http://127.0.0.1:8790 (requires its local development token)
- Spark UI: http://127.0.0.1:4040 while a Spark driver is running

Local object-storage credentials are `iceberg-local` / `iceberg-local-password`.
These are development-only credentials for the loopback Docker lab, not AWS keys.
The internal S3 service is named `minio` for compatibility; its implementation is
RustFS. Buckets are private and initialization does not delete bucket contents.
The job runner has no Docker socket or host filesystem mount.

Named Docker volumes persist object data, the REST catalog database, and job
history/logs. SQLite app configuration remains in the project's ignored `data/`
directory. Multiple local jobs are queued for one Spark executor to limit laptop
memory use. A worker-container restart marks interrupted jobs failed; it does not
automatically repeat potentially committed writes. Rescan before replanning.

## Stop and resume

```sh
docker compose -f compose.local.yaml stop
docker compose -f compose.local.yaml start
```

Stop the Python backend with Ctrl+C. To remove containers while retaining data:

```sh
docker compose -f compose.local.yaml down
```

Do not add `--volumes` unless you intend to permanently delete local lake data.

## Inspect problems

```sh
docker compose -f compose.local.yaml ps
docker compose -f compose.local.yaml logs --tail 100 spark-worker
docker compose -f compose.local.yaml exec spark-worker tail -n 100 /work/seed.log
```

Both AWS and local modes run the same maintenance job script and snapshot
preflight. Local mode uses a REST catalog and local Spark processes in place of
Glue and EMR Serverless. Before using AWS, separately validate IAM, Lake Formation,
KMS, network permissions, supported Iceberg versions, and a development-table run.
