#!/bin/zsh
set -e
cd -- "${0:A:h}"
if [[ -x .venv/bin/python ]]; then
  app_python="$PWD/.venv/bin/python"
elif [[ -x /opt/homebrew/bin/python3 ]]; then
  app_python=/opt/homebrew/bin/python3
else
  app_python=python3
fi
if ! "$app_python" -c 'import fastapi, uvicorn, boto3' >/dev/null 2>&1; then
  "$app_python" -m venv .venv
  app_python="$PWD/.venv/bin/python"
  "$app_python" -m pip install -r requirements.txt
fi
print 'Starting Iceberg Ops at http://127.0.0.1:8765'
exec "$app_python" run.py
